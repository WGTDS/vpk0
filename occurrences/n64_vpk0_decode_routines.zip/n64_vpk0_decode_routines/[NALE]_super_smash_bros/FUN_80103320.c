/*  vpk0 Decode Function Instance #6
 *  Decompiled from Super Smash Bros. [NALE]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;

void FUN_80103320( ushort *param_1 )
{
  undefined uVar1;
  ushort uVar2;
  uint uVar3;
  int *piVar4;
  int **unaff_s0;
  undefined *puVar5;
  int **ppiVar6;
  int iVar7;
  int unaff_s1;
  int iVar8;
  uint unaff_s2;
  int **unaff_s3;
  ushort *unaff_s4;
  ushort *unaff_s5;
  code *unaff_s6;
  int unaff_s7;
  undefined *unaff_s8;
  int in_stack_00000064;
  int in_stack_00000134;
  undefined *in_stack_00000138;
  int **in_stack_00000140;
  int **in_stack_00000144;
  
  do
  {
    do
    {
      if ( unaff_s1 < 1 )
      {
        if ( param_1 < unaff_s5 )
        {
          uVar2 = *param_1;
        }
        else
        {
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          param_1 = unaff_s4;
        }

        param_1 = param_1 + 1;
        unaff_s1 = unaff_s1 + 0x10;
        unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
      }

      unaff_s1 = unaff_s1 + -1;

      if ( (int)(unaff_s2 << (unaff_s7 - unaff_s1 & 0x1fU)) < 0 )
      {
        unaff_s0 = (int **)unaff_s0[1];
      }
      else
      {
        unaff_s0 = (int **)*unaff_s0;
      }
    }
    while ( *unaff_s0 != (int *)0x0 );

    piVar4 = unaff_s0[2];

    while ( true )
    {
      if ( unaff_s1 < (int)piVar4 )
      {
        if ( param_1 < unaff_s5 )
        {
          uVar2 = *param_1;
        }
        else
        {
          (*unaff_s6)();
          piVar4 = unaff_s0[2];
          uVar2 = *unaff_s4;
          param_1 = unaff_s4;
        }

        param_1 = param_1 + 1;
        unaff_s1 = unaff_s1 + 0x10;
        unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
      }

      unaff_s1 = unaff_s1 - (int)piVar4;
      uVar3 = (unaff_s2 << (-unaff_s1 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

      while ( true )
      {
        puVar5 = unaff_s8 + (uVar3 * -4 - in_stack_00000064) + 8;
        piVar4 = *in_stack_00000140;

        while ( true )
        {
          if ( piVar4 == (int *)0x0 )
          {
            piVar4 = unaff_s3[2];
          }
          else
          {
            do
            {
              if ( unaff_s1 < 1 )
              {
                if ( param_1 < unaff_s5 )
                {
                  uVar2 = *param_1;
                }
                else
                {
                  (*unaff_s6)();
                  uVar2 = *unaff_s4;
                  param_1 = unaff_s4;
                }

                param_1 = param_1 + 1;
                unaff_s1 = unaff_s1 + 0x10;
                unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
              }

              unaff_s1 = unaff_s1 + -1;

              if ( (int)(unaff_s2 << (unaff_s7 - unaff_s1 & 0x1fU)) < 0 )
              {
                unaff_s3 = (int **)unaff_s3[1];
              }
              else
              {
                unaff_s3 = (int **)*unaff_s3;
              }
            }
            while ( *unaff_s3 != (int *)0x0 );

            piVar4 = unaff_s3[2];
          }

          if ( unaff_s1 < (int)piVar4 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              piVar4 = unaff_s3[2];
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            unaff_s1 = unaff_s1 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          iVar8 = unaff_s1 - (int)piVar4;
          uVar3 = (unaff_s2 << (-iVar8 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

          while ( 0 < (int)uVar3 )
          {
            uVar3 = uVar3 - 1;
            uVar1 = *puVar5;
            puVar5 = puVar5 + 1;
            *unaff_s8 = uVar1;
            unaff_s8 = unaff_s8 + 1;
          }

          while ( true )
          {
            if ( in_stack_00000138 <= unaff_s8 )
            {
              return;
            }
            if ( iVar8 < 1 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar8 = iVar8 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar7 = iVar8 + -1;

            if ( (int)(unaff_s2 << (unaff_s7 - iVar7 & 0x1fU)) < 0 ) break;

            if ( iVar7 < 8 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar7 = iVar8 + 0xf;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar8 = iVar7 + -8;
            *unaff_s8 = (char)((unaff_s2 << (0x18U - iVar8 & 0x1f)) >> 0x18);
            unaff_s8 = unaff_s8 + 1;
          }

          piVar4 = *in_stack_00000144;
          ppiVar6 = in_stack_00000144;
          unaff_s3 = in_stack_00000140;

          if ( in_stack_00000134 != 0 ) break;

          while ( piVar4 != (int *)0x0 )
          {
            if ( iVar7 < 1 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar7 = iVar7 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar7 = iVar7 + -1;

            if ( (int)(unaff_s2 << (unaff_s7 - iVar7 & 0x1fU)) < 0 )
            {
              ppiVar6 = (int **)ppiVar6[1];
            }
            else
            {
              ppiVar6 = (int **)*ppiVar6;
            }

            piVar4 = *ppiVar6;
          }

          iVar8 = (int)ppiVar6[2];

          if ( iVar7 < iVar8 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              iVar8 = (int)ppiVar6[2];
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar7 = iVar7 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          unaff_s1 = iVar7 - iVar8;
          puVar5 = unaff_s8 + -((unaff_s2 << (-unaff_s1 - iVar8 & 0x1fU)) >> (-iVar8 & 0x1fU));
          piVar4 = *in_stack_00000140;
        }

        while ( piVar4 != (int *)0x0 )
        {
          if ( iVar7 < 1 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar7 = iVar7 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          iVar7 = iVar7 + -1;

          if ( (int)(unaff_s2 << (unaff_s7 - iVar7 & 0x1fU)) < 0 )
          {
            ppiVar6 = (int **)ppiVar6[1];
          }
          else
          {
            ppiVar6 = (int **)*ppiVar6[1];
          }

          piVar4 = *ppiVar6;
        }

        piVar4 = ppiVar6[2];

        if ( iVar7 < (int)piVar4 )
        {
          if ( param_1 < unaff_s5 )
          {
            uVar2 = *param_1;
          }
          else
          {
            (*unaff_s6)();
            piVar4 = ppiVar6[2];
            uVar2 = *unaff_s4;
            param_1 = unaff_s4;
          }

          param_1 = param_1 + 1;
          iVar7 = iVar7 + 0x10;
          unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
        }

        unaff_s1 = iVar7 - (int)piVar4;
        uVar3 = (unaff_s2 << (-unaff_s1 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

        if ( (int)uVar3 < 3 ) break;

        in_stack_00000064 = 0;
      }

      in_stack_00000064 = uVar3 + 1;
      unaff_s0 = in_stack_00000144;

      if ( *in_stack_00000144 != (int *)0x0 ) break;

      piVar4 = in_stack_00000144[2];
    }
  }
  while ( true );
}
