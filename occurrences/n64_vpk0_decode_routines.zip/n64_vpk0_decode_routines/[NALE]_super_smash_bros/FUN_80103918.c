/*  vpk0 Decode Function Instance #9
 *  Decompiled from Super Smash Bros. [NALE]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;

void FUN_80103918( ushort *param_1, undefined4 param_2, int param_3, int param_4 )
{
  undefined uVar1;
  ushort uVar2;
  int in_v0;
  int iVar3;
  uint in_v1;
  int **ppiVar4;
  undefined *in_t0;
  int **in_t1;
  int in_t3;
  int *in_t4;
  undefined *in_t5;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  undefined *puVar9;
  int param_11;
  
  iVar3 = in_v0 + -8;

  do
  {
    uVar2 = *param_1;
    param_1 = param_1 + 1;
    in_v1 = in_v1 << 0x10 | (uint)uVar2;
    iVar3 = iVar3 + 8;

    while ( true )
    {
      *in_t0 = (char)((in_v1 << (in_t3 - iVar3 & 0x1fU)) >> 0x18);
      in_t0 = in_t0 + 1;

      while( true )
      {
        if ( in_t5 <= in_t0 )
        {
          return;
        }

        if ( iVar3 < 1 )
        {
          uVar2 = *param_1;
          param_1 = param_1 + 1;
          in_v1 = in_v1 << 0x10 | (uint)uVar2;
          iVar3 = iVar3 + 0xf;
        }
        else
        {
          iVar3 = iVar3 + -1;
        }

        if ( -1 < (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) ) break;

        piVar8 = *in_t1;
        ppiVar4 = in_t1;

        if ( param_11 == 0 )
        {
          while ( piVar8 != (int *)0x0 )
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar4 = (int **)ppiVar4[1];
            }
            else
            {
              ppiVar4 = (int **)*ppiVar4;
            }

            piVar8 = *ppiVar4;
          }

          piVar8 = ppiVar4[2];

          if ( iVar3 < (int)piVar8 )
          {
            uVar2 = *param_1;
            param_1 = param_1 + 1;
            iVar3 = iVar3 + 0x10;
            in_v1 = in_v1 << 0x10 | (uint)uVar2;
          }

          iVar3 = iVar3 - (int)piVar8;
          iVar6 = -((in_v1 << ((param_3 - (int)piVar8) - iVar3 & 0x1fU)) >> (param_3 - (int)piVar8 & 0x1fU));
        }
        else
        {
          iVar6 = 0;
          piVar5 = piVar8;

          while ( piVar5 != (int *)0x0 )
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar4 = (int **)ppiVar4[1];
            }
            else
            {
              ppiVar4 = (int **)*ppiVar4;
            }

            piVar5 = *ppiVar4;
          }

          piVar5 = ppiVar4[2];

          if ( iVar3 < (int)piVar5 )
          {
            uVar2 = *param_1;
            param_1 = param_1 + 1;
            iVar3 = iVar3 + 0x10;
            in_v1 = in_v1 << 0x10 | (uint)uVar2;
          }

          iVar3 = iVar3 - (int)piVar5;
          uVar7 = (in_v1 << ((param_3 - (int)piVar5) - iVar3 & 0x1fU)) >> (param_3 - (int)piVar5 & 0x1fU);

          if ((int)uVar7 < 3)
          {
            iVar6 = uVar7 + 1;
            ppiVar4 = in_t1;

            while ( piVar8 != (int *)0x0 )
            {
              if ( iVar3 < 1 )
              {
                uVar2 = *param_1;
                param_1 = param_1 + 1;
                in_v1 = in_v1 << 0x10 | (uint)uVar2;
                iVar3 = iVar3 + 0xf;
              }
              else
              {
                iVar3 = iVar3 + -1;
              }

              if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
              {
                ppiVar4 = (int **)ppiVar4[1];
              }
              else
              {
                ppiVar4 = (int **)*ppiVar4;
              }

              piVar8 = *ppiVar4;
            }

            piVar8 = ppiVar4[2];

            if ( iVar3 < (int)piVar8 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              iVar3 = iVar3 + 0x10;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
            }

            iVar3 = iVar3 - (int)piVar8;
            uVar7 = (in_v1 << ((param_3 - (int)piVar8) - iVar3 & 0x1fU)) >> (param_3 - (int)piVar8 & 0x1fU);
          }

          iVar6 = (uVar7 * -4 - iVar6) + 8;
        }

        puVar9 = in_t0 + iVar6;
        ppiVar4 = (int **)in_t4;

        if ( *in_t4 == 0 )
        {
          iVar6 = in_t4[2];
        }
        else
        {
          do
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar4 = (int **)ppiVar4[1];
            }
            else
            {
              ppiVar4 = (int **)*ppiVar4;
            }
          }
          while ( *ppiVar4 != (int *)0x0 );

          iVar6 = ((int *)ppiVar4)[2];
        }

        if ( iVar3 < iVar6 )
        {
          uVar2 = *param_1;
          param_1 = param_1 + 1;
          iVar3 = iVar3 + 0x10;
          in_v1 = in_v1 << 0x10 | (uint)uVar2;
        }

        iVar3 = iVar3 - iVar6;
        uVar7 = (in_v1 << ((param_3 - iVar6) - iVar3 & 0x1fU)) >> (param_3 - iVar6 & 0x1fU);

        while ( 0 < (int)uVar7 )
        {
          uVar7 = uVar7 - 1;
          uVar1 = *puVar9;
          puVar9 = puVar9 + 1;
          *in_t0 = uVar1;
          in_t0 = in_t0 + 1;
        }
      }

      if ( iVar3 < 8 ) break;

      iVar3 = iVar3 + -8;
    }
  }
  while ( true );
}
