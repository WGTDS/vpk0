/*  vpk0 Decode Function Instance #7
 *  Decompiled from Super Smash Bros. [NALE]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;

void FUN_80103378( ushort *param_1 )
{
  undefined uVar1;
  ushort uVar2;
  uint uVar3;
  int *piVar4;
  int *in_t3;
  int **unaff_s0;
  undefined *puVar5;
  int **ppiVar6;
  int iVar7;
  int unaff_s1;
  int iVar8;
  uint unaff_s2;
  int **unaff_s3;
  ushort *unaff_s4;
  ushort *unaff_s5;
  code *unaff_s6;
  int unaff_s7;
  undefined *unaff_s8;
  int param_17;
  int param_18;
  undefined *param_19;
  int **param_20;
  int **param_21;
  
  do
  {
    if ( in_t3 == (int *)0x0 )
    {
      piVar4 = unaff_s0[2];

      while ( true )
      {
        if ( unaff_s1 < (int)piVar4 )
        {
          if ( param_1 < unaff_s5 )
          {
            uVar2 = *param_1;
          }
          else
          {
            (*unaff_s6)();
            piVar4 = unaff_s0[2];
            uVar2 = *unaff_s4;
            param_1 = unaff_s4;
          }

          param_1 = param_1 + 1;
          unaff_s1 = unaff_s1 + 0x10;
          unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
        }

        unaff_s1 = unaff_s1 - (int)piVar4;
        uVar3 = (unaff_s2 << (-unaff_s1 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

        while ( true )
        {
          puVar5 = unaff_s8 + (uVar3 * -4 - param_17) + 8;
          piVar4 = *param_20;

          while ( true )
          {
            if ( piVar4 == (int *)0x0 )
            {
              piVar4 = unaff_s3[2];
            }
            else
            {
              do
              {
                if ( unaff_s1 < 1 )
                {
                  if ( param_1 < unaff_s5 )
                  {
                    uVar2 = *param_1;
                  }
                  else
                  {
                    (*unaff_s6)();
                    uVar2 = *unaff_s4;
                    param_1 = unaff_s4;
                  }

                  param_1 = param_1 + 1;
                  unaff_s1 = unaff_s1 + 0x10;
                  unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
                }

                unaff_s1 = unaff_s1 + -1;

                if ( (int)(unaff_s2 << (unaff_s7 - unaff_s1 & 0x1fU)) < 0 )
                {
                  unaff_s3 = (int **)unaff_s3[1];
                }
                else
                {
                  unaff_s3 = (int **)*unaff_s3;
                }
              }
              while ( *unaff_s3 != (int *)0x0 );

              piVar4 = unaff_s3[2];
            }

            if ( unaff_s1 < (int)piVar4 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                piVar4 = unaff_s3[2];
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              unaff_s1 = unaff_s1 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar8 = unaff_s1 - (int)piVar4;
            uVar3 = (unaff_s2 << (-iVar8 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

            while ( 0 < (int)uVar3 )
            {
              uVar3 = uVar3 - 1;
              uVar1 = *puVar5;
              puVar5 = puVar5 + 1;
              *unaff_s8 = uVar1;
              unaff_s8 = unaff_s8 + 1;
            }

            while ( true )
            {
              if ( param_19 <= unaff_s8 )
              {
                return;
              }

              if ( iVar8 < 1 )
              {
                if ( param_1 < unaff_s5 )
                {
                  uVar2 = *param_1;
                }
                else
                {
                  (*unaff_s6)();
                  uVar2 = *unaff_s4;
                  param_1 = unaff_s4;
                }

                param_1 = param_1 + 1;
                iVar8 = iVar8 + 0x10;
                unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
              }

              iVar7 = iVar8 + -1;

              if ( (int)(unaff_s2 << (unaff_s7 - iVar7 & 0x1fU)) < 0 ) break;

              if ( iVar7 < 8 )
              {
                if ( param_1 < unaff_s5 )
                {
                  uVar2 = *param_1;
                }
                else
                {
                  (*unaff_s6)();
                  uVar2 = *unaff_s4;
                  param_1 = unaff_s4;
                }

                param_1 = param_1 + 1;
                iVar7 = iVar8 + 0xf;
                unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
              }

              iVar8 = iVar7 + -8;
              *unaff_s8 = (char)((unaff_s2 << (0x18U - iVar8 & 0x1f)) >> 0x18);
              unaff_s8 = unaff_s8 + 1;
            }

            piVar4 = *param_21;
            ppiVar6 = param_21;
            unaff_s3 = param_20;

            if ( param_18 != 0 ) break;

            while ( piVar4 != (int *)0x0 )
            {
              if ( iVar7 < 1 )
              {
                if ( param_1 < unaff_s5 )
                {
                  uVar2 = *param_1;
                }
                else
                {
                  (*unaff_s6)();
                  uVar2 = *unaff_s4;
                  param_1 = unaff_s4;
                }

                param_1 = param_1 + 1;
                iVar7 = iVar7 + 0x10;
                unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
              }

              iVar7 = iVar7 + -1;

              if ( (int)(unaff_s2 << (unaff_s7 - iVar7 & 0x1fU)) < 0 )
              {
                ppiVar6 = (int **)ppiVar6[1];
              }
              else
              {
                ppiVar6 = (int **)*ppiVar6;
              }

              piVar4 = *ppiVar6;
            }

            piVar4 = ppiVar6[2];

            if ( iVar7 < (int)piVar4 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                piVar4 = ppiVar6[2];
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar7 = iVar7 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            unaff_s1 = iVar7 - (int)piVar4;
            puVar5 = unaff_s8 + -((unaff_s2 << (-unaff_s1 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU));
            piVar4 = *param_20;
          }

          while ( piVar4 != (int *)0x0 )
          {
            if ( iVar7 < 1 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar7 = iVar7 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar7 = iVar7 + -1;

            if ( (int)(unaff_s2 << (unaff_s7 - iVar7 & 0x1fU)) < 0 )
            {
              ppiVar6 = (int **)ppiVar6[1];
            }
            else
            {
              ppiVar6 = (int **)*ppiVar6;
            }

            piVar4 = *ppiVar6;
          }

          iVar8 = (int)ppiVar6[2];

          if ( iVar7 < iVar8 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              iVar8 = (int)ppiVar6[2];
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar7 = iVar7 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          unaff_s1 = iVar7 - iVar8;
          uVar3 = (unaff_s2 << (-unaff_s1 - iVar8 & 0x1fU)) >> (-iVar8 & 0x1fU);

          if ( (int)uVar3 < 3 ) break;

          param_17 = 0;
        }

        param_17 = uVar3 + 1;
        unaff_s0 = param_21;

        if ( *param_21 != (int *)0x0 ) break;

        piVar4 = param_21[2];
      }
    }

    if ( unaff_s1 < 1 )
    {
      if ( param_1 < unaff_s5 )
      {
        uVar2 = *param_1;
      }
      else
      {
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        param_1 = unaff_s4;
      }

      param_1 = param_1 + 1;
      unaff_s1 = unaff_s1 + 0x10;
      unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
    }

    unaff_s1 = unaff_s1 + -1;

    if ( (int)(unaff_s2 << (unaff_s7 - unaff_s1 & 0x1fU)) < 0 )
    {
      unaff_s0 = (int **)unaff_s0[1];
    }
    else
    {
      unaff_s0 = (int **)*unaff_s0;
    }

    in_t3 = *unaff_s0;
  }
  while ( true );
}
