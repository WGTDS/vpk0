/*  vpk0 Decode Function Instance #5
 *  Decompiled from Super Smash Bros. [NALE]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;
typedef uint undefined4;

void FUN_80103150( ushort *param_1 )
{
  undefined4 *puVar1;
  undefined uVar2;
  ushort uVar3;
  int iVar4;
  undefined4 *in_v0;
  int *piVar5;
  uint uVar6;
  int in_v1;
  int iVar7;
  uint in_t7;
  undefined4 *unaff_s0;
  int **ppiVar8;
  undefined *puVar9;
  int iVar10;
  int unaff_s1;
  uint unaff_s2;
  uint uVar11;
  undefined4 *unaff_s3;
  int *piVar12;
  ushort *unaff_s4;
  ushort *unaff_s5;
  code *unaff_s6;
  int unaff_s7;
  undefined *unaff_s8;
  int iStack00000064;
  int param_12;
  int *param_13;
  int in_stack_00000134;
  undefined *param_14;
  int *param_15;
  int **in_stack_00000144;
  undefined *param_16;
  
  do
  {
    uVar11 = unaff_s2 | in_t7;

    do
    {
      in_v0[2] = (uVar11 << (0x18U - (unaff_s1 + -8) & 0x1f)) >> 0x18;
      *(undefined4 **)unaff_s0 = in_v0;
      in_v1 = in_v1 + 1;
      iVar10 = unaff_s1 + -8;
      in_v0 = unaff_s3;

      while ( true )
      {
        if ( iVar10 < 1 )
        {
          if ( param_1 < unaff_s5 )
          {
            uVar3 = *param_1;
          }
          else
          {
            param_12 = in_v1;
            (*unaff_s6)();
            uVar3 = *unaff_s4;
            in_v1 = param_12;
            param_1 = unaff_s4;
          }

          param_1 = param_1 + 1;
          iVar10 = iVar10 + 0x10;
          uVar11 = uVar11 << 0x10 | (uint)uVar3;
        }

        unaff_s1 = iVar10 + -1;
        iVar4 = uVar11 << (unaff_s7 - unaff_s1 & 0x1fU);

        if ( (iVar4 < 0) && (in_v1 < 2) )
        {
          param_15 = param_13;
          if ( param_16 < param_14 )
          {
            do
            {
              if ( unaff_s1 < 1 )
              {
                if ( param_1 < unaff_s5 )
                {
                  uVar3 = *param_1;
                }
                else
                {
                  (*unaff_s6)();
                  uVar3 = *unaff_s4;
                  param_1 = unaff_s4;
                }

                param_1 = param_1 + 1;
                unaff_s1 = unaff_s1 + 0x10;
                uVar11 = uVar11 << 0x10 | (uint)uVar3;
              }

              piVar12 = param_15;
              iVar10 = unaff_s1 + -1;

              if ( (int)(uVar11 << (unaff_s7 - iVar10 & 0x1fU)) < 0 )
              {
                piVar5 = *in_stack_00000144;
                ppiVar8 = in_stack_00000144;

                if ( in_stack_00000134 == 0 )
                {
                  while ( piVar5 != (int *)0x0 )
                  {
                    if ( iVar10 < 1 )
                    {
                      if ( param_1 < unaff_s5 )
                      {
                        uVar3 = *param_1;
                      }
                      else
                      {
                        (*unaff_s6)();
                        uVar3 = *unaff_s4;
                        param_1 = unaff_s4;
                      }

                      param_1 = param_1 + 1;
                      iVar10 = iVar10 + 0x10;
                      uVar11 = uVar11 << 0x10 | (uint)uVar3;
                    }

                    iVar10 = iVar10 + -1;

                    if ( (int)(uVar11 << (unaff_s7 - iVar10 & 0x1fU)) < 0 )
                    {
                      ppiVar8 = (int **)ppiVar8[1];
                    }
                    else
                    {
                      ppiVar8 = (int **)*ppiVar8;
                    }

                    piVar5 = *ppiVar8;
                  }

                  piVar5 = ppiVar8[2];

                  if ( iVar10 < (int)piVar5 )
                  {
                    if ( param_1 < unaff_s5 )
                    {
                      uVar3 = *param_1;
                    }
                    else
                    {
                      (*unaff_s6)();
                      piVar5 = ppiVar8[2];
                      uVar3 = *unaff_s4;
                      param_1 = unaff_s4;
                    }

                    param_1 = param_1 + 1;
                    iVar10 = iVar10 + 0x10;
                    uVar11 = uVar11 << 0x10 | (uint)uVar3;
                  }

                  iVar10 = iVar10 - (int)piVar5;
                  iVar4 = -((uVar11 << (-iVar10 - (int)piVar5 & 0x1fU)) >> (-(int)piVar5 & 0x1fU));
                  iVar7 = *param_15;
                }
                else
                {
                  iStack00000064 = 0;

                  while ( piVar5 != (int *)0x0 )
                  {
                    if ( iVar10 < 1 )
                    {
                      if ( param_1 < unaff_s5 )
                      {
                        uVar3 = *param_1;
                      }
                      else
                      {
                        (*unaff_s6)();
                        uVar3 = *unaff_s4;
                        param_1 = unaff_s4;
                      }

                      param_1 = param_1 + 1;
                      iVar10 = iVar10 + 0x10;
                      uVar11 = uVar11 << 0x10 | (uint)uVar3;
                    }

                    iVar10 = iVar10 + -1;

                    if ( (int)(uVar11 << (unaff_s7 - iVar10 & 0x1fU)) < 0 )
                    {
                      ppiVar8 = (int **)ppiVar8[1];
                    }
                    else
                    {
                      ppiVar8 = (int **)*ppiVar8;
                    }

                    piVar5 = *ppiVar8;
                  }

                  piVar5 = ppiVar8[2];

                  if ( iVar10 < (int)piVar5 )
                  {
                    if ( param_1 < unaff_s5 )
                    {
                      uVar3 = *param_1;
                    }
                    else
                    {
                      (*unaff_s6)();
                      piVar5 = ppiVar8[2];
                      uVar3 = *unaff_s4;
                      param_1 = unaff_s4;
                    }

                    param_1 = param_1 + 1;
                    iVar10 = iVar10 + 0x10;
                    uVar11 = uVar11 << 0x10 | (uint)uVar3;
                  }

                  iVar10 = iVar10 - (int)piVar5;
                  uVar6 = (uVar11 << (-iVar10 - (int)piVar5 & 0x1fU)) >> (-(int)piVar5 & 0x1fU);

                  if ( (int)uVar6 < 3 )
                  {
                    iStack00000064 = uVar6 + 1;
                    ppiVar8 = in_stack_00000144;

                    if ( *in_stack_00000144 == (int *)0x0 )
                    {
                      piVar5 = in_stack_00000144[2];
                    }
                    else
                    {
                      do
                      {
                        if ( iVar10 < 1 )
                        {
                          if ( param_1 < unaff_s5 )
                          {
                            uVar3 = *param_1;
                          }
                          else
                          {
                            (*unaff_s6)();
                            uVar3 = *unaff_s4;
                            param_1 = unaff_s4;
                          }

                          param_1 = param_1 + 1;
                          iVar10 = iVar10 + 0x10;
                          uVar11 = uVar11 << 0x10 | (uint)uVar3;
                        }

                        iVar10 = iVar10 + -1;

                        if ( (int)(uVar11 << (unaff_s7 - iVar10 & 0x1fU)) < 0 )
                        {
                          ppiVar8 = (int **)ppiVar8[1];
                        }
                        else
                        {
                          ppiVar8 = (int **)*ppiVar8;
                        }
                      }
                      while ( *ppiVar8 != (int *)0x0 );

                      piVar5 = ppiVar8[2];
                    }

                    if ( iVar10 < (int)piVar5 )
                    {
                      if ( param_1 < unaff_s5 )
                      {
                        uVar3 = *param_1;
                      }
                      else
                      {
                        (*unaff_s6)();
                        piVar5 = ppiVar8[2];
                        uVar3 = *unaff_s4;
                        param_1 = unaff_s4;
                      }

                      param_1 = param_1 + 1;
                      iVar10 = iVar10 + 0x10;
                      uVar11 = uVar11 << 0x10 | (uint)uVar3;
                    }

                    iVar10 = iVar10 - (int)piVar5;
                    uVar6 = (uVar11 << (-iVar10 - (int)piVar5 & 0x1fU)) >> (-(int)piVar5 & 0x1fU);
                  }

                  iVar4 = (uVar6 * -4 - iStack00000064) + 8;
                  iVar7 = *param_15;
                }

                puVar9 = unaff_s8 + iVar4;

                if ( iVar7 == 0 )
                {
                  iVar4 = piVar12[2];
                }
                else
                {
                  do
                  {
                    if ( iVar10 < 1 )
                    {
                      if ( param_1 < unaff_s5 )
                      {
                        uVar3 = *param_1;
                      }
                      else
                      {
                        (*unaff_s6)();
                        uVar3 = *unaff_s4;
                        param_1 = unaff_s4;
                      }

                      param_1 = param_1 + 1;
                      iVar10 = iVar10 + 0x10;
                      uVar11 = uVar11 << 0x10 | (uint)uVar3;
                    }

                    iVar10 = iVar10 + -1;

                    if ( (int)(uVar11 << (unaff_s7 - iVar10 & 0x1fU)) < 0 )
                    {
                      piVar12 = (int *)piVar12[1];
                    }
                    else
                    {
                      piVar12 = *(int **)piVar12[1];
                    }
                  }
                  while ( *piVar12 != 0 );

                  iVar4 = piVar12[2];
                }

                if ( iVar10 < iVar4 )
                {
                  if ( param_1 < unaff_s5 )
                  {
                    uVar3 = *param_1;
                  }
                  else
                  {
                    (*unaff_s6)();
                    iVar4 = piVar12[2];
                    uVar3 = *unaff_s4;
                    param_1 = unaff_s4;
                  }

                  param_1 = param_1 + 1;
                  iVar10 = iVar10 + 0x10;
                  uVar11 = uVar11 << 0x10 | (uint)uVar3;
                }

                unaff_s1 = iVar10 - iVar4;
                uVar6 = (uVar11 << (-unaff_s1 - iVar4 & 0x1fU)) >> (-iVar4 & 0x1fU);

                while ( 0 < (int)uVar6 )
                {
                  uVar6 = uVar6 - 1;
                  uVar2 = *puVar9;
                  puVar9 = puVar9 + 1;
                  *unaff_s8 = uVar2;
                  unaff_s8 = unaff_s8 + 1;
                }
              }
              else
              {
                if ( iVar10 < 8 )
                {
                  if ( param_1 < unaff_s5 )
                  {
                    uVar3 = *param_1;
                  }
                  else
                  {
                    (*unaff_s6)();
                    uVar3 = *unaff_s4;
                    param_1 = unaff_s4;
                  }

                  param_1 = param_1 + 1;
                  iVar10 = unaff_s1 + 0xf;
                  uVar11 = uVar11 << 0x10 | (uint)uVar3;
                }

                unaff_s1 = iVar10 + -8;
                *unaff_s8 = (char)((uVar11 << (0x18U - unaff_s1 & 0x1f)) >> 0x18);
                unaff_s8 = unaff_s8 + 1;
              }
            }
            while ( unaff_s8 < param_14 );
          }

          return;
        }

        iVar7 = in_v1 * 4;
        unaff_s0 = &stack0x00000084 + in_v1;

        if ( -1 < iVar4 ) break;

        *in_v0 = 0;
        in_v0[1] = 0;
        in_v0[2] = 0;
        *in_v0 = *(undefined4 *)(&stack0x0000007c + iVar7);
        puVar1 = &stack0x00000080 + in_v1;
        in_v1 = in_v1 + -1;
        in_v0[1] = *puVar1;
        *(undefined4 **)(&stack0x0000007c + iVar7) = in_v0;
        iVar10 = unaff_s1;
        in_v0 = in_v0 + 3;
      }

      unaff_s3 = in_v0 + 3;
      *in_v0 = 0;
      in_v0[1] = 0;
      in_v0[2] = 0;
    }
    while ( 7 < unaff_s1 );

    if ( param_1 < unaff_s5 )
    {
      uVar3 = *param_1;
    }
    else
    {
      param_12 = in_v1;
      (*unaff_s6)();
      uVar3 = *unaff_s4;
      in_v1 = param_12;
      param_1 = unaff_s4;
    }

    in_t7 = (uint)uVar3;
    unaff_s2 = uVar11 << 0x10;
    param_1 = param_1 + 1;
    unaff_s1 = iVar10 + 0xf;
  }
  while ( true );
}
