/*  vpk0 Decode Function Instance #3
 *  Decompiled from Super Smash Bros. [NALE]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;
typedef uint undefined4;

void FUN_80102f90( ushort *param_1 )
{
  undefined uVar1;
  ushort uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int in_v1;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  int **ppiVar11;
  undefined *puVar12;
  int unaff_s1;
  uint unaff_s2;
  undefined4 *unaff_s3;
  int **ppiVar13;
  ushort *unaff_s4;
  ushort *unaff_s5;
  code *unaff_s6;
  int unaff_s7;
  undefined *unaff_s8;
  int iStack00000064;
  int in_stack_00000080;
  int **in_stack_00000084;
  undefined4 *param_11;
  int param_12;
  int **in_stack_000000e4;
  int in_stack_00000134;
  undefined *in_stack_00000138;
  int **in_stack_00000140;
  int **in_stack_00000144;
  undefined *in_stack_00000464;
  
  while ( true )
  {
    iVar3 = unaff_s2 << (unaff_s7 - unaff_s1 & 0x1fU);

    if ( (iVar3 < 0) && (in_v1 < 2) ) break;

    iVar8 = in_v1 * 4;
    puVar10 = &stack0x000000e4 + in_v1;

    if ( iVar3 < 0 )
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;
      *unaff_s3 = *(undefined4 *)(&stack0x000000dc + iVar8);
      puVar10 = &stack0x000000e0 + in_v1;
      in_v1 = in_v1 + -1;
      unaff_s3[1] = *puVar10;
      *(undefined4 **)(&stack0x000000dc + iVar8) = unaff_s3;
    }
    else
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;
      puVar4 = unaff_s3;

      if ( unaff_s1 < 8 )
      {
        if ( param_1 < unaff_s5 )
        {
          uVar2 = *param_1;
        }
        else
        {
          param_11 = unaff_s3;
          param_12 = in_v1;
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          puVar4 = param_11;
          in_v1 = param_12;
          param_1 = unaff_s4;
        }

        param_1 = param_1 + 1;
        unaff_s1 = unaff_s1 + 0x10;
        unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
      }

      unaff_s1 = unaff_s1 + -8;
      puVar4[2] = (unaff_s2 << (0x18U - unaff_s1 & 0x1f)) >> 0x18;
      *(undefined4 **)puVar10 = puVar4;
      in_v1 = in_v1 + 1;
    }

    unaff_s3 = unaff_s3 + 3;

    if ( unaff_s1 < 1 )
    {
      if ( param_1 < unaff_s5 )
      {
        uVar2 = *param_1;
      }
      else
      {
        param_12 = in_v1;
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        in_v1 = param_12;
        param_1 = unaff_s4;
      }

      param_1 = param_1 + 1;
      unaff_s1 = unaff_s1 + 0x10;
      unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
    }

    unaff_s1 = unaff_s1 + -1;
  }

  iVar3 = 0;
  in_stack_00000084 = (int **)0x0;
  in_stack_00000144 = in_stack_000000e4;

  while ( true )
  {
    iVar8 = unaff_s1;

    if ( unaff_s1 < 1 )
    {
      if ( param_1 < unaff_s5 )
      {
        uVar2 = *param_1;
      }
      else
      {
        in_stack_00000080 = iVar3;
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        iVar3 = in_stack_00000080;
        param_1 = unaff_s4;
      }

      param_1 = param_1 + 1;
      iVar8 = unaff_s1 + 0x10;
      unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
    }

    unaff_s1 = iVar8 + -1;
    iVar5 = unaff_s2 << (unaff_s7 - unaff_s1 & 0x1fU);

    if ( (iVar5 < 0) && (iVar3 < 2) ) break;

    iVar9 = iVar3 * 4;
    puVar10 = &stack0x00000084 + iVar3;

    if ( iVar5 < 0 )
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;
      *unaff_s3 = *(undefined4 *)(&stack0x0000007c + iVar9);
      puVar10 = &stack0x00000080 + iVar3;
      iVar3 = iVar3 + -1;
      unaff_s3[1] = *puVar10;
      *(undefined4 **)(&stack0x0000007c + iVar9) = unaff_s3;
      unaff_s3 = unaff_s3 + 3;
    }
    else
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;

      if ( unaff_s1 < 8 )
      {
        if ( param_1 < unaff_s5 )
        {
          uVar2 = *param_1;
        }
        else
        {
          in_stack_00000080 = iVar3;
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          iVar3 = in_stack_00000080;
          param_1 = unaff_s4;
        }

        param_1 = param_1 + 1;
        unaff_s1 = iVar8 + 0xf;
        unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
      }

      unaff_s1 = unaff_s1 + -8;
      unaff_s3[2] = (unaff_s2 << (0x18U - unaff_s1 & 0x1f)) >> 0x18;
      *(undefined4 **)puVar10 = unaff_s3;
      iVar3 = iVar3 + 1;
      unaff_s3 = unaff_s3 + 3;
    }
  }

  in_stack_00000140 = in_stack_00000084;

  if ( in_stack_00000464 < in_stack_00000138 )
  {
    do
    {
      if ( unaff_s1 < 1 )
      {
        if ( param_1 < unaff_s5 )
        {
          uVar2 = *param_1;
        }
        else
        {
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          param_1 = unaff_s4;
        }

        param_1 = param_1 + 1;
        unaff_s1 = unaff_s1 + 0x10;
        unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
      }

      ppiVar13 = in_stack_00000140;
      iVar3 = unaff_s1 + -1;

      if ( (int)(unaff_s2 << (unaff_s7 - iVar3 & 0x1fU)) < 0 )
      {
        piVar6 = *in_stack_00000144;
        ppiVar11 = in_stack_00000144;

        if ( in_stack_00000134 == 0 )
        {
          while ( piVar6 != (int *)0x0 )
          {
            if ( iVar3 < 1 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar3 = iVar3 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar3 = iVar3 + -1;

            if ( (int)(unaff_s2 << (unaff_s7 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar11 = (int **)ppiVar11[1];
            }
            else
            {
              ppiVar11 = (int **)*ppiVar11;
            }

            piVar6 = *ppiVar11;
          }

          piVar6 = ppiVar11[2];

          if ( iVar3 < (int)piVar6 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              piVar6 = ppiVar11[2];
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar3 = iVar3 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          iVar3 = iVar3 - (int)piVar6;
          iVar8 = -((unaff_s2 << (-iVar3 - (int)piVar6 & 0x1fU)) >> (-(int)piVar6 & 0x1fU));
          piVar6 = *in_stack_00000140;
        }
        else
        {
          iStack00000064 = 0;

          while ( piVar6 != (int *)0x0 )
          {
            if ( iVar3 < 1 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar3 = iVar3 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar3 = iVar3 + -1;

            if ( (int)(unaff_s2 << (unaff_s7 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar11 = (int **)ppiVar11[1];
            }
            else
            {
              ppiVar11 = (int **)*ppiVar11;
            }

            piVar6 = *ppiVar11;
          }

          piVar6 = ppiVar11[2];

          if ( iVar3 < (int)piVar6 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              piVar6 = ppiVar11[2];
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar3 = iVar3 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          iVar3 = iVar3 - (int)piVar6;
          uVar7 = (unaff_s2 << (-iVar3 - (int)piVar6 & 0x1fU)) >> (-(int)piVar6 & 0x1fU);

          if ( (int)uVar7 < 3 )
          {
            iStack00000064 = uVar7 + 1;
            ppiVar11 = in_stack_00000144;

            if ( *in_stack_00000144 == (int *)0x0 )
            {
              piVar6 = in_stack_00000144[2];
            }
            else
            {
              do
              {
                if ( iVar3 < 1 )
                {
                  if ( param_1 < unaff_s5 )
                  {
                    uVar2 = *param_1;
                  }
                  else
                  {
                    (*unaff_s6)();
                    uVar2 = *unaff_s4;
                    param_1 = unaff_s4;
                  }

                  param_1 = param_1 + 1;
                  iVar3 = iVar3 + 0x10;
                  unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
                }

                iVar3 = iVar3 + -1;

                if ( (int)(unaff_s2 << (unaff_s7 - iVar3 & 0x1fU)) < 0 )
                {
                  ppiVar11 = (int **)ppiVar11[1];
                }
                else
                {
                  ppiVar11 = (int **)*ppiVar11;
                }
              }
              while ( *ppiVar11 != (int *)0x0 );

              piVar6 = ppiVar11[2];
            }

            if ( iVar3 < (int)piVar6 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                piVar6 = ppiVar11[2];
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar3 = iVar3 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar3 = iVar3 - (int)piVar6;
            uVar7 = (unaff_s2 << (-iVar3 - (int)piVar6 & 0x1fU)) >> (-(int)piVar6 & 0x1fU);
          }

          iVar8 = (uVar7 * -4 - iStack00000064) + 8;
          piVar6 = *in_stack_00000140;
        }

        puVar12 = unaff_s8 + iVar8;

        if ( piVar6 == (int *)0x0 )
        {
          piVar6 = ppiVar13[2];
        }
        else
        {
          do
          {
            if ( iVar3 < 1 )
            {
              if ( param_1 < unaff_s5 )
              {
                uVar2 = *param_1;
              }
              else
              {
                (*unaff_s6)();
                uVar2 = *unaff_s4;
                param_1 = unaff_s4;
              }

              param_1 = param_1 + 1;
              iVar3 = iVar3 + 0x10;
              unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
            }

            iVar3 = iVar3 + -1;

            if ( (int)(unaff_s2 << (unaff_s7 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar13 = (int **)ppiVar13[1];
            }
            else
            {
              ppiVar13 = (int **)*ppiVar13;
            }
          }
          while ( *ppiVar13 != (int *)0x0 );

          piVar6 = ppiVar13[2];
        }

        if ( iVar3 < (int)piVar6 )
        {
          if ( param_1 < unaff_s5 )
          {
            uVar2 = *param_1;
          }
          else
          {
            (*unaff_s6)();
            piVar6 = ppiVar13[2];
            uVar2 = *unaff_s4;
            param_1 = unaff_s4;
          }

          param_1 = param_1 + 1;
          iVar3 = iVar3 + 0x10;
          unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
        }

        unaff_s1 = iVar3 - (int)piVar6;
        uVar7 = (unaff_s2 << (-unaff_s1 - (int)piVar6 & 0x1fU)) >> (-(int)piVar6 & 0x1fU);

        while ( 0 < (int)uVar7 )
        {
          uVar7 = uVar7 - 1;
          uVar1 = *puVar12;
          puVar12 = puVar12 + 1;
          *unaff_s8 = uVar1;
          unaff_s8 = unaff_s8 + 1;
        }
      }
      else
      {
        if ( iVar3 < 8 )
        {
          if ( param_1 < unaff_s5 )
          {
            uVar2 = *param_1;
          }
          else
          {
            (*unaff_s6)();
            uVar2 = *unaff_s4;
            param_1 = unaff_s4;
          }

          param_1 = param_1 + 1;
          iVar3 = unaff_s1 + 0xf;
          unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
        }

        unaff_s1 = iVar3 + -8;
        *unaff_s8 = (char)((unaff_s2 << (0x18U - unaff_s1 & 0x1f)) >> 0x18);
        unaff_s8 = unaff_s8 + 1;
      }
    }
    while ( unaff_s8 < in_stack_00000138 );
  }

  return;
}
