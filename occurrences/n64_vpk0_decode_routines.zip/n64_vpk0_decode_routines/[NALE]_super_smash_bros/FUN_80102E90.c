/*  vpk0 Decode Function Instance #2
 *  Decompiled from Super Smash Bros. [NALE]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;
typedef uint undefined4;

void FUN_80102e90( ushort *param_1, undefined param_2, undefined param_3, undefined param_4,
                   undefined param_5, undefined param_6, undefined param_7, undefined param_8,
                   undefined param_9, undefined param_10, int **param_11, uint param_12,
                   undefined *param_13, undefined *param_14 )
{
  undefined uVar1;
  ushort uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  ushort *puVar7;
  int iVar8;
  undefined4 *puVar9;
  int **ppiVar10;
  undefined *puVar11;
  int unaff_s1;
  int iVar12;
  int iVar13;
  uint uVar14;
  undefined4 *unaff_s3;
  undefined4 *puVar15;
  int **ppiVar16;
  ushort *unaff_s4;
  ushort *unaff_s5;
  code *unaff_s6;
  undefined *puVar17;
  int iStack00000064;
  int in_stack_00000080;
  int **ppiStack00000084;
  undefined4 *in_stack_000000d4;
  int in_stack_000000e0;
  int **ppiStack00000140;
  int **ppiStack00000144;
  
  puVar17 = param_14;

  if ( unaff_s5 <= param_1 )
  {
    (*unaff_s6)();
    param_1 = unaff_s4;
  }

  uVar2 = *param_1;
  puVar7 = param_1 + 1;

  if ( unaff_s5 <= param_1 + 1 )
  {
    (*unaff_s6)();
    puVar7 = unaff_s4;
  }

  iVar12 = unaff_s1 + -0x10;
  uVar14 = CONCAT22( uVar2, *puVar7 );
  param_13 = param_14 + (uVar14 << (-iVar12 & 0x1fU));
  puVar7 = puVar7 + 1;

  if ( iVar12 < 8 )
  {
    if ( puVar7 < unaff_s5 )
    {
      uVar2 = *puVar7;
    }
    else
    {
      (*unaff_s6)();
      uVar2 = *unaff_s4;
      puVar7 = unaff_s4;
    }

    puVar7 = puVar7 + 1;
    uVar14 = uVar14 << 0x10 | (uint)uVar2;
    iVar12 = unaff_s1;
  }

  iVar12 = iVar12 + -8;
  param_12 = (uVar14 << (0x18U - iVar12 & 0x1f)) >> 0x18;
  iVar6 = 0;
  param_11 = (int **)0x0;

  while ( true )
  {
    iVar13 = iVar12;

    if ( iVar12 < 1 )
    {
      if ( puVar7 < unaff_s5 )
      {
        uVar2 = *puVar7;
      }
      else
      {
        in_stack_000000e0 = iVar6;
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        iVar6 = in_stack_000000e0;
        puVar7 = unaff_s4;
      }

      puVar7 = puVar7 + 1;
      iVar13 = iVar12 + 0x10;
      uVar14 = uVar14 << 0x10 | (uint)uVar2;
    }

    iVar12 = iVar13 + -1;
    iVar3 = uVar14 << (0x1fU - iVar12 & 0x1f);

    if ((iVar3 < 0) && (iVar6 < 2)) break;

    iVar8 = iVar6 * 4;
    puVar9 = &param_11 + iVar6;

    if ( iVar3 < 0 )
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;
      *unaff_s3 = *(undefined4 *)(&stack0x000000dc + iVar8);
      iVar6 = iVar6 + -1;
      unaff_s3[1] = *(undefined4 *)(&stack0x000000e0 + iVar8);
      *(undefined4 **)(&stack0x000000dc + iVar8) = unaff_s3;
      unaff_s3 = unaff_s3 + 3;
    }
    else
    {
      puVar15 = unaff_s3 + 3;
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;

      if ( iVar12 < 8 )
      {
        if ( puVar7 < unaff_s5 )
        {
          uVar2 = *puVar7;
        }
        else
        {
          in_stack_000000d4 = unaff_s3;
          in_stack_000000e0 = iVar6;
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          unaff_s3 = in_stack_000000d4;
          iVar6 = in_stack_000000e0;
          puVar7 = unaff_s4;
        }

        puVar7 = puVar7 + 1;
        iVar12 = iVar13 + 0xf;
        uVar14 = uVar14 << 0x10 | (uint)uVar2;
      }

      iVar12 = iVar12 + -8;
      unaff_s3[2] = (uVar14 << (0x18U - iVar12 & 0x1f)) >> 0x18;
      *(undefined4 **)puVar9 = unaff_s3;
      iVar6 = iVar6 + 1;
      unaff_s3 = puVar15;
    }
  }

  iVar6 = 0;
  ppiStack00000084 = (int **)0x0;
  ppiStack00000144 = param_11;

  while( true )
  {
    iVar13 = iVar12;

    if ( iVar12 < 1 )
    {
      if ( puVar7 < unaff_s5 )
      {
        uVar2 = *puVar7;
      }
      else
      {
        in_stack_00000080 = iVar6;
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        iVar6 = in_stack_00000080;
        puVar7 = unaff_s4;
      }

      puVar7 = puVar7 + 1;
      iVar13 = iVar12 + 0x10;
      uVar14 = uVar14 << 0x10 | (uint)uVar2;
    }

    iVar12 = iVar13 + -1;
    iVar3 = uVar14 << (0x1fU - iVar12 & 0x1f);

    if ( (iVar3 < 0) && (ppiStack00000140 = ppiStack00000084, iVar6 < 2) ) break;

    iVar8 = iVar6 * 4;

    if ( iVar3 < 0 )
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;
      *unaff_s3 = *(undefined4 *)(&stack0x0000007c + iVar8);
      puVar9 = &stack0x00000080 + iVar6;
      iVar6 = iVar6 + -1;
      unaff_s3[1] = *puVar9;
      *(undefined4 **)(&stack0x0000007c + iVar8) = unaff_s3;
      unaff_s3 = unaff_s3 + 3;
    }
    else
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;

      if ( iVar12 < 8 )
      {
        if ( puVar7 < unaff_s5 )
        {
          uVar2 = *puVar7;
        }
        else
        {
          in_stack_00000080 = iVar6;
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          iVar6 = in_stack_00000080;
          puVar7 = unaff_s4;
        }

        puVar7 = puVar7 + 1;
        iVar12 = iVar13 + 0xf;
        uVar14 = uVar14 << 0x10 | (uint)uVar2;
      }

      iVar12 = iVar12 + -8;
      unaff_s3[2] = (uVar14 << (0x18U - iVar12 & 0x1f)) >> 0x18;
      *(undefined4 **)(&stack0x00000084 + iVar8) = unaff_s3;
      iVar6 = iVar6 + 1;
      unaff_s3 = unaff_s3 + 3;
    }
  }

  while ( param_14 < param_13 )
  {
    if ( iVar12 < 1 )
    {
      if ( puVar7 < unaff_s5 )
      {
        uVar2 = *puVar7;
      }
      else
      {
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        puVar7 = unaff_s4;
      }

      puVar7 = puVar7 + 1;
      iVar12 = iVar12 + 0x10;
      uVar14 = uVar14 << 0x10 | (uint)uVar2;
    }

    ppiVar16 = ppiStack00000140;
    iVar6 = iVar12 + -1;

    if ( (int)(uVar14 << (0x1fU - iVar6 & 0x1f)) < 0 )
    {
      piVar4 = *ppiStack00000144;
      ppiVar10 = ppiStack00000144;

      if ( param_12 == 0 )
      {
        while ( piVar4 != (int *)0x0 )
        {
          if ( iVar6 < 1 )
          {
            if ( puVar7 < unaff_s5 )
            {
              uVar2 = *puVar7;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              puVar7 = unaff_s4;
            }

            puVar7 = puVar7 + 1;
            iVar6 = iVar6 + 0x10;
            uVar14 = uVar14 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(uVar14 << (0x1fU - iVar6 & 0x1f)) < 0 )
          {
            ppiVar10 = (int **)ppiVar10[1];
          }
          else
          {
            ppiVar10 = (int **)*ppiVar10;
          }

          piVar4 = *ppiVar10;
        }

        piVar4 = ppiVar10[2];

        if ( iVar6 < (int)piVar4 )
        {
          if ( puVar7 < unaff_s5 )
          {
            uVar2 = *puVar7;
          }
          else
          {
            (*unaff_s6)();
            piVar4 = ppiVar10[2];
            uVar2 = *unaff_s4;
            puVar7 = unaff_s4;
          }

          puVar7 = puVar7 + 1;
          iVar6 = iVar6 + 0x10;
          uVar14 = uVar14 << 0x10 | (uint)uVar2;
        }

        iVar6 = iVar6 - (int)piVar4;
        iVar12 = -((uVar14 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU));
        piVar4 = *ppiStack00000140;
      }
      else
      {
        iStack00000064 = 0;

        while ( piVar4 != (int *)0x0 )
        {
          if ( iVar6 < 1 )
          {
            if ( puVar7 < unaff_s5 )
            {
              uVar2 = *puVar7;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              puVar7 = unaff_s4;
            }

            puVar7 = puVar7 + 1;
            iVar6 = iVar6 + 0x10;
            uVar14 = uVar14 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(uVar14 << (0x1fU - iVar6 & 0x1f)) < 0 )
          {
            ppiVar10 = (int **)ppiVar10[1];
          }
          else
          {
            ppiVar10 = (int **)*ppiVar10;
          }

          piVar4 = *ppiVar10;
        }

        piVar4 = ppiVar10[2];

        if ( iVar6 < (int)piVar4 )
        {
          if ( puVar7 < unaff_s5 )
          {
            uVar2 = *puVar7;
          }
          else
          {
            (*unaff_s6)();
            piVar4 = ppiVar10[2];
            uVar2 = *unaff_s4;
            puVar7 = unaff_s4;
          }

          puVar7 = puVar7 + 1;
          iVar6 = iVar6 + 0x10;
          uVar14 = uVar14 << 0x10 | (uint)uVar2;
        }

        iVar6 = iVar6 - (int)piVar4;
        uVar5 = (uVar14 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

        if ( (int)uVar5 < 3 )
        {
          iStack00000064 = uVar5 + 1;
          ppiVar10 = ppiStack00000144;

          if ( *ppiStack00000144 == (int *)0x0 )
          {
            piVar4 = ppiStack00000144[2];
          }
          else
          {
            do
            {
              if ( iVar6 < 1 )
              {
                if ( puVar7 < unaff_s5 )
                {
                  uVar2 = *puVar7;
                }
                else
                {
                  (*unaff_s6)();
                  uVar2 = *unaff_s4;
                  puVar7 = unaff_s4;
                }

                puVar7 = puVar7 + 1;
                iVar6 = iVar6 + 0x10;
                uVar14 = uVar14 << 0x10 | (uint)uVar2;
              }

              iVar6 = iVar6 + -1;

              if ( (int)(uVar14 << (0x1fU - iVar6 & 0x1f)) < 0 )
              {
                ppiVar10 = (int **)ppiVar10[1];
              }
              else
              {
                ppiVar10 = (int **)*ppiVar10;
              }
            }
            while ( *ppiVar10 != (int *)0x0 );

            piVar4 = ppiVar10[2];
          }

          if ( iVar6 < (int)piVar4 )
          {
            if ( puVar7 < unaff_s5 )
            {
              uVar2 = *puVar7;
            }
            else
            {
              (*unaff_s6)();
              piVar4 = ppiVar10[2];
              uVar2 = *unaff_s4;
              puVar7 = unaff_s4;
            }

            puVar7 = puVar7 + 1;
            iVar6 = iVar6 + 0x10;
            uVar14 = uVar14 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 - (int)piVar4;
          uVar5 = (uVar14 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);
        }

        iVar12 = (uVar5 * -4 - iStack00000064) + 8;
        piVar4 = *ppiStack00000140;
      }

      puVar11 = puVar17 + iVar12;

      if ( piVar4 == (int *)0x0 )
      {
        piVar4 = ppiVar16[2];
      }
      else
      {
        do
        {
          if ( iVar6 < 1 )
          {
            if ( puVar7 < unaff_s5 )
            {
              uVar2 = *puVar7;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              puVar7 = unaff_s4;
            }

            puVar7 = puVar7 + 1;
            iVar6 = iVar6 + 0x10;
            uVar14 = uVar14 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(uVar14 << (0x1fU - iVar6 & 0x1f)) < 0 )
          {
            ppiVar16 = (int **)ppiVar16[1];
          }
          else
          {
            ppiVar16 = (int **)*ppiVar16;
          }
        }
        while ( *ppiVar16 != (int *)0x0 );

        piVar4 = ppiVar16[2];
      }

      if ( iVar6 < (int)piVar4 )
      {
        if ( puVar7 < unaff_s5 )
        {
          uVar2 = *puVar7;
        }
        else
        {
          (*unaff_s6)();
          piVar4 = ppiVar16[2];
          uVar2 = *unaff_s4;
          puVar7 = unaff_s4;
        }

        puVar7 = puVar7 + 1;
        iVar6 = iVar6 + 0x10;
        uVar14 = uVar14 << 0x10 | (uint)uVar2;
      }

      iVar12 = iVar6 - (int)piVar4;
      uVar5 = (uVar14 << (-iVar12 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

      while ( param_14 = puVar17, 0 < (int)uVar5 )
      {
        uVar5 = uVar5 - 1;
        uVar1 = *puVar11;
        puVar11 = puVar11 + 1;
        *puVar17 = uVar1;
        puVar17 = puVar17 + 1;
      }
    }
    else
    {
      if ( iVar6 < 8 )
      {
        if ( puVar7 < unaff_s5 )
        {
          uVar2 = *puVar7;
        }
        else
        {
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          puVar7 = unaff_s4;
        }

        puVar7 = puVar7 + 1;
        iVar6 = iVar12 + 0xf;
        uVar14 = uVar14 << 0x10 | (uint)uVar2;
      }

      iVar12 = iVar6 + -8;
      *puVar17 = (char)((uVar14 << (0x18U - iVar12 & 0x1f)) >> 0x18);
      puVar17 = puVar17 + 1;
      param_14 = puVar17;
    }
  }

  return;
}
