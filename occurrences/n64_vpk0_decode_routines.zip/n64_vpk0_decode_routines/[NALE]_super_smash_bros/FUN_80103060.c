/*  vpk0 Decode Function Instance #4
 *  Decompiled from Super Smash Bros. [NALE]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;
typedef uint undefined4;

void FUN_80103060( ushort *param_1, undefined param_2, undefined param_3, undefined param_4,
                   undefined param_5, undefined param_6, undefined param_7, undefined param_8,
                   undefined param_9, undefined param_10, int **param_11, int **param_12, int **param_13)
{
  undefined uVar1;
  ushort uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  int **ppiVar9;
  undefined *puVar10;
  int unaff_s1;
  int iVar11;
  uint unaff_s2;
  undefined4 *unaff_s3;
  int **ppiVar12;
  ushort *unaff_s4;
  ushort *unaff_s5;
  code *unaff_s6;
  int unaff_s7;
  undefined *unaff_s8;
  int iStack00000064;
  int in_stack_00000080;
  int in_stack_00000134;
  undefined *in_stack_00000138;
  int **ppiStack00000140;
  undefined *in_stack_00000464;
  
  iVar6 = 0;
  param_11 = (int **)0x0;
  param_13 = param_12;

  while ( true )
  {
    iVar11 = unaff_s1;

    if ( unaff_s1 < 1 )
    {
      if ( param_1 < unaff_s5 )
      {
        uVar2 = *param_1;
      }
      else
      {
        in_stack_00000080 = iVar6;
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        iVar6 = in_stack_00000080;
        param_1 = unaff_s4;
      }

      param_1 = param_1 + 1;
      iVar11 = unaff_s1 + 0x10;
      unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
    }

    unaff_s1 = iVar11 + -1;
    iVar3 = unaff_s2 << (unaff_s7 - unaff_s1 & 0x1fU);

    if ((iVar3 < 0) && (ppiStack00000140 = param_11, iVar6 < 2)) break;

    iVar7 = iVar6 * 4;
    puVar8 = &param_11 + iVar6;

    if ( iVar3 < 0 )
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;
      *unaff_s3 = *(undefined4 *)(&stack0x0000007c + iVar7);
      iVar6 = iVar6 + -1;
      unaff_s3[1] = *(undefined4 *)(&stack0x00000080 + iVar7);
      *(undefined4 **)(&stack0x0000007c + iVar7) = unaff_s3;
      unaff_s3 = unaff_s3 + 3;
    }
    else
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;

      if ( unaff_s1 < 8 )
      {
        if ( param_1 < unaff_s5 )
        {
          uVar2 = *param_1;
        }
        else
        {
          in_stack_00000080 = iVar6;
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          iVar6 = in_stack_00000080;
          param_1 = unaff_s4;
        }

        param_1 = param_1 + 1;
        unaff_s1 = iVar11 + 0xf;
        unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
      }

      unaff_s1 = unaff_s1 + -8;
      unaff_s3[2] = (unaff_s2 << (0x18U - unaff_s1 & 0x1f)) >> 0x18;
      *(undefined4 **)puVar8 = unaff_s3;
      iVar6 = iVar6 + 1;
      unaff_s3 = unaff_s3 + 3;
    }
  }

  while ( in_stack_00000464 < in_stack_00000138 )
  {
    if ( unaff_s1 < 1 )
    {
      if ( param_1 < unaff_s5 )
      {
        uVar2 = *param_1;
      }
      else
      {
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        param_1 = unaff_s4;
      }

      param_1 = param_1 + 1;
      unaff_s1 = unaff_s1 + 0x10;
      unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
    }

    ppiVar12 = ppiStack00000140;
    iVar6 = unaff_s1 + -1;

    if ( (int)(unaff_s2 << (unaff_s7 - iVar6 & 0x1fU)) < 0 )
    {
      piVar4 = *param_13;
      ppiVar9 = param_13;

      if ( in_stack_00000134 == 0 )
      {
        while ( piVar4 != (int *)0x0 )
        {
          if ( iVar6 < 1 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar6 = iVar6 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(unaff_s2 << (unaff_s7 - iVar6 & 0x1fU)) < 0 )
          {
            ppiVar9 = (int **)ppiVar9[1];
          }
          else
          {
            ppiVar9 = (int **)*ppiVar9;
          }

          piVar4 = *ppiVar9;
        }

        piVar4 = ppiVar9[2];

        if ( iVar6 < (int)piVar4 )
        {
          if ( param_1 < unaff_s5 )
          {
            uVar2 = *param_1;
          }
          else
          {
            (*unaff_s6)();
            piVar4 = ppiVar9[2];
            uVar2 = *unaff_s4;
            param_1 = unaff_s4;
          }

          param_1 = param_1 + 1;
          iVar6 = iVar6 + 0x10;
          unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
        }

        iVar6 = iVar6 - (int)piVar4;
        iVar11 = -((unaff_s2 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU));
        piVar4 = *ppiStack00000140;
      }
      else
      {
        iStack00000064 = 0;

        while ( piVar4 != (int *)0x0 )
        {
          if ( iVar6 < 1 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar6 = iVar6 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(unaff_s2 << (unaff_s7 - iVar6 & 0x1fU)) < 0 )
          {
            ppiVar9 = (int **)ppiVar9[1];
          }
          else
          {
            ppiVar9 = (int **)*ppiVar9[1];
          }

          piVar4 = *ppiVar9;
        }

        piVar4 = ppiVar9[2];

        if ( iVar6 < (int)piVar4 )
        {
          if ( param_1 < unaff_s5 )
          {
            uVar2 = *param_1;
          }
          else
          {
            (*unaff_s6)();
            piVar4 = ppiVar9[2];
            uVar2 = *unaff_s4;
            param_1 = unaff_s4;
          }

          param_1 = param_1 + 1;
          iVar6 = iVar6 + 0x10;
          unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
        }

        iVar6 = iVar6 - (int)piVar4;
        uVar5 = (unaff_s2 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

        if ( (int)uVar5 < 3 )
        {
          iStack00000064 = uVar5 + 1;
          ppiVar9 = param_13;

          if ( *param_13 == (int *)0x0 )
          {
            piVar4 = param_13[2];
          }
          else
          {
            do
            {
              if ( iVar6 < 1 )
              {
                if ( param_1 < unaff_s5 )
                {
                  uVar2 = *param_1;
                }
                else
                {
                  (*unaff_s6)();
                  uVar2 = *unaff_s4;
                  param_1 = unaff_s4;
                }

                param_1 = param_1 + 1;
                iVar6 = iVar6 + 0x10;
                unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
              }

              iVar6 = iVar6 + -1;

              if ( (int)(unaff_s2 << (unaff_s7 - iVar6 & 0x1fU)) < 0 )
              {
                ppiVar9 = (int **)ppiVar9[1];
              }
              else
              {
                ppiVar9 = (int **)*ppiVar9[1];
              }
            }
            while ( *ppiVar9 != (int *)0x0 );

            piVar4 = ppiVar9[2];
          }

          if ( iVar6 < (int)piVar4 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              piVar4 = ppiVar9[2];
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar6 = iVar6 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 - (int)piVar4;
          uVar5 = (unaff_s2 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);
        }

        iVar11 = (uVar5 * -4 - iStack00000064) + 8;
        piVar4 = *ppiStack00000140;
      }

      puVar10 = unaff_s8 + iVar11;

      if ( piVar4 == (int *)0x0 )
      {
        piVar4 = ppiVar12[2];
      }
      else
      {
        do
        {
          if ( iVar6 < 1 )
          {
            if ( param_1 < unaff_s5 )
            {
              uVar2 = *param_1;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              param_1 = unaff_s4;
            }

            param_1 = param_1 + 1;
            iVar6 = iVar6 + 0x10;
            unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(unaff_s2 << (unaff_s7 - iVar6 & 0x1fU)) < 0 )
          {
            ppiVar12 = (int **)ppiVar12[1];
          }
          else
          {
            ppiVar12 = (int **)*ppiVar12;
          }
        }
        while ( *ppiVar12 != (int *)0x0 );

        piVar4 = ppiVar12[2];
      }

      if ( iVar6 < (int)piVar4 )
      {
        if ( param_1 < unaff_s5 )
        {
          uVar2 = *param_1;
        }
        else
        {
          (*unaff_s6)();
          piVar4 = ppiVar12[2];
          uVar2 = *unaff_s4;
          param_1 = unaff_s4;
        }

        param_1 = param_1 + 1;
        iVar6 = iVar6 + 0x10;
        unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
      }

      unaff_s1 = iVar6 - (int)piVar4;
      uVar5 = (unaff_s2 << (-unaff_s1 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

      while ( in_stack_00000464 = unaff_s8, 0 < (int)uVar5 )
      {
        uVar5 = uVar5 - 1;
        uVar1 = *puVar10;
        puVar10 = puVar10 + 1;
        *unaff_s8 = uVar1;
        unaff_s8 = unaff_s8 + 1;
      }
    }
    else
    {
      if ( iVar6 < 8 )
      {
        if ( param_1 < unaff_s5 )
        {
          uVar2 = *param_1;
        }
        else
        {
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          param_1 = unaff_s4;
        }

        param_1 = param_1 + 1;
        iVar6 = unaff_s1 + 0xf;
        unaff_s2 = unaff_s2 << 0x10 | (uint)uVar2;
      }

      unaff_s1 = iVar6 + -8;
      *unaff_s8 = (char)((unaff_s2 << (0x18U - unaff_s1 & 0x1f)) >> 0x18);
      unaff_s8 = unaff_s8 + 1;
      in_stack_00000464 = unaff_s8;
    }
  }

  return;
}
