/*  vpk0 Decode Function Instance #5
 *  Decompiled from Kirby 64: The Crystal Shards [NK4E]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;
typedef uint undefined4;

void FUN_80103930( ushort *param_1, undefined *param_2, undefined4 *param_3, int param_4 )
{
  undefined uVar1;
  ushort uVar2;
  int iVar3;
  int in_v0;
  uint in_v1;
  int **ppiVar4;
  undefined4 *puVar5;
  undefined *in_t0;
  int in_t1;
  int iVar6;
  int iVar7;
  int in_t3;
  undefined4 *in_t4;
  undefined *in_t5;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  undefined *puVar11;
  int iVar12;
  int *param_11;
  int **param_12;
  int in_stack_0000010c;
  
  do
  {
    *param_3 = in_t4[-2];
    in_t1 = in_t1 + -1;
    param_3[1] = in_t4[-1];
    *(undefined4 **)(in_t4 + -2) = param_3;
    puVar5 = param_3;

    while ( true )
    {
      param_3 = puVar5 + 3;
      iVar3 = in_v0;

      if ( in_v0 < 1 )
      {
        uVar2 = *param_1;
        param_1 = param_1 + 1;
        iVar3 = in_v0 + 0x10;
        in_v1 = in_v1 << 0x10 | (uint)uVar2;
      }

      in_v0 = iVar3 + -1;
      iVar6 = in_v1 << (param_4 - in_v0 & 0x1fU);

      if ( (iVar6 < 0) && (in_t1 < 2) )
      {
        iVar3 = 0;
        param_11 = (int *)0x0;

        while ( true )
        {
          iVar6 = in_v0;

          if ( in_v0 < 1 )
          {
            uVar2 = *param_1;
            param_1 = param_1 + 1;
            iVar6 = in_v0 + 0x10;
            in_v1 = in_v1 << 0x10 | (uint)uVar2;
          }

          in_v0 = iVar6 + -1;
          iVar7 = in_v1 << (param_4 - in_v0 & 0x1fU);
          iVar12 = iVar3 * 4;

          if ( (iVar7 < 0) && (iVar3 < 2) ) break;

          if ( iVar7 < 0 )
          {
            *param_3 = 0;
            param_3[1] = 0;
            param_3[2] = 0;
            *param_3 = *(undefined4 *)(&stack0x00000054 + iVar12);
            iVar3 = iVar3 + -1;
            param_3[1] = *(undefined4 *)(&stack0x00000058 + iVar12);
            *(undefined4 **)(&stack0x00000054 + iVar12) = param_3;
            param_3 = param_3 + 3;
          }
          else
          {
            *param_3 = 0;
            param_3[1] = 0;
            param_3[2] = 0;

            if ( in_v0 < 8 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              in_v0 = iVar6 + 0xf;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
            }

            in_v0 = in_v0 + -8;
            param_3[2] = (in_v1 << (in_t3 - in_v0 & 0x1fU)) >> 0x18;
            *(undefined4 **)(&stack0x0000005c + iVar12) = param_3;
            iVar3 = iVar3 + 1;
            param_3 = param_3 + 3;
          }
        }

        if ( param_2 < in_t5 )
        {
          do
          {
            if ( in_v0 < 1 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
              iVar3 = in_v0 + 0xf;
            }
            else
            {
              iVar3 = in_v0 + -1;
            }

            if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
            {
              piVar10 = *param_12;
              ppiVar4 = param_12;

              if ( in_stack_0000010c == 0 )
              {
                while ( piVar10 != (int *)0x0 )
                {
                  if ( iVar3 < 1 )
                  {
                    uVar2 = *param_1;
                    param_1 = param_1 + 1;
                    in_v1 = in_v1 << 0x10 | (uint)uVar2;
                    iVar3 = iVar3 + 0xf;
                  }
                  else
                  {
                    iVar3 = iVar3 + -1;
                  }

                  if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
                  {
                    ppiVar4 = (int **)ppiVar4[1];
                  }
                  else
                  {
                    ppiVar4 = (int **)*ppiVar4;
                  }

                  piVar10 = *ppiVar4;
                }

                piVar10 = ppiVar4[2];

                if ( iVar3 < (int)piVar10 )
                {
                  uVar2 = *param_1;
                  param_1 = param_1 + 1;
                  iVar3 = iVar3 + 0x10;
                  in_v1 = in_v1 << 0x10 | (uint)uVar2;
                }

                iVar3 = iVar3 - (int)piVar10;
                iVar6 = -((in_v1 << ((0x20 - (int)piVar10) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar10 & 0x1f));
              }
              else
              {
                iVar6 = 0;
                piVar8 = piVar10;

                while ( piVar8 != (int *)0x0 )
                {
                  if ( iVar3 < 1 )
                  {
                    uVar2 = *param_1;
                    param_1 = param_1 + 1;
                    in_v1 = in_v1 << 0x10 | (uint)uVar2;
                    iVar3 = iVar3 + 0xf;
                  }
                  else
                  {
                    iVar3 = iVar3 + -1;
                  }

                  if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
                  {
                    ppiVar4 = (int **)ppiVar4[1];
                  }
                  else
                  {
                    ppiVar4 = (int **)*ppiVar4;
                  }

                  piVar8 = *ppiVar4;
                }

                piVar8 = ppiVar4[2];

                if ( iVar3 < (int)piVar8 )
                {
                  uVar2 = *param_1;
                  param_1 = param_1 + 1;
                  iVar3 = iVar3 + 0x10;
                  in_v1 = in_v1 << 0x10 | (uint)uVar2;
                }

                iVar3 = iVar3 - (int)piVar8;
                uVar9 = (in_v1 << ((0x20 - (int)piVar8) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar8 & 0x1f);

                if ( (int)uVar9 < 3 )
                {
                  iVar6 = uVar9 + 1;
                  ppiVar4 = param_12;

                  while ( piVar10 != (int *)0x0 )
                  {
                    if ( iVar3 < 1 )
                    {
                      uVar2 = *param_1;
                      param_1 = param_1 + 1;
                      in_v1 = in_v1 << 0x10 | (uint)uVar2;
                      iVar3 = iVar3 + 0xf;
                    }
                    else
                    {
                      iVar3 = iVar3 + -1;
                    }

                    if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
                    {
                      ppiVar4 = (int **)ppiVar4[1];
                    }
                    else
                    {
                      ppiVar4 = (int **)*ppiVar4;
                    }

                    piVar10 = *ppiVar4;
                  }

                  piVar10 = ppiVar4[2];

                  if ( iVar3 < (int)piVar10 )
                  {
                    uVar2 = *param_1;
                    param_1 = param_1 + 1;
                    iVar3 = iVar3 + 0x10;
                    in_v1 = in_v1 << 0x10 | (uint)uVar2;
                  }

                  iVar3 = iVar3 - (int)piVar10;
                  uVar9 = (in_v1 << ((0x20 - (int)piVar10) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar10 & 0x1f);
                }

                iVar6 = (uVar9 * -4 - iVar6) + 8;
              }

              puVar11 = in_t0 + iVar6;
              ppiVar4 = (int **)param_11;

              if ( *param_11 == 0 )
              {
                iVar6 = param_11[2];
              }
              else
              {
                do
                {
                  if ( iVar3 < 1 )
                  {
                    uVar2 = *param_1;
                    param_1 = param_1 + 1;
                    in_v1 = in_v1 << 0x10 | (uint)uVar2;
                    iVar3 = iVar3 + 0xf;
                  }
                  else
                  {
                    iVar3 = iVar3 + -1;
                  }

                  if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
                  {
                    ppiVar4 = (int **)ppiVar4[1];
                  }
                  else
                  {
                    ppiVar4 = (int **)*ppiVar4;
                  }
                }
                while ( *ppiVar4 != (int *)0x0 );

                iVar6 = ((int *)ppiVar4)[2];
              }

              if ( iVar3 < iVar6 )
              {
                uVar2 = *param_1;
                param_1 = param_1 + 1;
                iVar3 = iVar3 + 0x10;
                in_v1 = in_v1 << 0x10 | (uint)uVar2;
              }

              in_v0 = iVar3 - iVar6;
              uVar9 = (in_v1 << ((0x20 - iVar6) - in_v0 & 0x1fU)) >> (0x20U - iVar6 & 0x1f);

              while ( 0 < (int)uVar9 )
              {
                uVar9 = uVar9 - 1;
                uVar1 = *puVar11;
                puVar11 = puVar11 + 1;
                *in_t0 = uVar1;
                in_t0 = in_t0 + 1;
              }
            }
            else
            {
              if ( iVar3 < 8 )
              {
                uVar2 = *param_1;
                param_1 = param_1 + 1;
                in_v1 = in_v1 << 0x10 | (uint)uVar2;
                in_v0 = iVar3 + 8;
              }
              else
              {
                in_v0 = iVar3 + -8;
              }

              *in_t0 = (char)((in_v1 << (in_t3 - in_v0 & 0x1fU)) >> 0x18);
              in_t0 = in_t0 + 1;
            }
          }
          while ( in_t0 < in_t5 );
        }

        return;
      }

      in_t4 = &stack0x000000bc + in_t1;

      if ( iVar6 < 0 ) break;

      *param_3 = 0;
      puVar5[4] = 0;
      puVar5[5] = 0;

      if ( in_v0 < 8 )
      {
        uVar2 = *param_1;
        param_1 = param_1 + 1;
        in_v0 = iVar3 + 0xf;
        in_v1 = in_v1 << 0x10 | (uint)uVar2;
      }

      in_v0 = in_v0 + -8;
      puVar5[5] = (in_v1 << (in_t3 - in_v0 & 0x1fU)) >> 0x18;
      *(undefined4 **)in_t4 = param_3;
      in_t1 = in_t1 + 1;
      puVar5 = param_3;
    }

    *param_3 = 0;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  while ( true );
}
