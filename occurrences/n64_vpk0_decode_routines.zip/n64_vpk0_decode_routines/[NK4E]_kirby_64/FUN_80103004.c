/*  vpk0 Decode Function Instance #2
 *  Decompiled from Kirby 64: The Crystal Shards [NK4E]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;
typedef uint undefined4;

void FUN_80103004( undefined param_1, undefined param_2, undefined param_3, undefined param_4,
                   undefined param_5, undefined param_6, undefined param_7, undefined param_8,
                   undefined param_9, undefined param_10, undefined4 param_11, undefined4 param_12,
                   int param_13, int **param_14, undefined4 param_15, undefined4 param_16, int param_17,
                   int **param_18, uint param_19, undefined *param_20, undefined4 param_21,int **param_22,
                   undefined *param_23)
{
  undefined uVar1;
  ushort uVar2;
  int **ppiVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  ushort *puVar8;
  ushort *puVar9;
  int unaff_s0;
  undefined4 *puVar10;
  int **ppiVar11;
  undefined *puVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  undefined4 *unaff_s3;
  ushort *unaff_s4;
  ushort *puVar16;
  code *unaff_s6;
  undefined *puVar17;
  int in_stack_00000064;
  
  puVar17 = param_23;
  puVar16 = (ushort *)((int)unaff_s4 + unaff_s0);
  puVar9 = unaff_s4 + 1;

  if ( puVar16 <= unaff_s4 + 1 )
  {
    (*unaff_s6)();
    puVar9 = unaff_s4;
  }

  puVar8 = puVar9 + 1;

  if ( puVar16 <= puVar9 + 1 )
  {
    (*unaff_s6)();
    puVar8 = unaff_s4;
  }

  uVar2 = *puVar8;
  iVar13 = 0;
  puVar9 = puVar8 + 1;

  if ( puVar16 <= puVar8 + 1 )
  {
    (*unaff_s6)();
    puVar9 = unaff_s4;
  }

  uVar15 = CONCAT22( uVar2, *puVar9 );
  param_20 = param_23 + uVar15;
  puVar9 = puVar9 + 1;

  if ( true )
  {
    if ( puVar9 < puVar16 )
    {
      uVar2 = *puVar9;
    }
    else
    {
      (*unaff_s6)();
      uVar2 = *unaff_s4;
      puVar9 = unaff_s4;
    }

    puVar9 = puVar9 + 1;
    iVar13 = 0x10;
    uVar15 = uVar15 << 0x10 | (uint)uVar2;
  }

  iVar13 = iVar13 + -8;
  param_19 = (uVar15 << (0x18U - iVar13 & 0x1f)) >> 0x18;
  iVar6 = 0;
  param_18 = (int **)0x0;

  while ( true )
  {
    iVar7 = iVar6;
    iVar14 = iVar13;

    if ( iVar13 < 1 )
    {
      if ( puVar9 < puVar16 )
      {
        uVar2 = *puVar9;
      }
      else
      {
        param_17 = iVar6;
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        iVar7 = param_17;
        puVar9 = unaff_s4;
      }

      puVar9 = puVar9 + 1;
      iVar14 = iVar13 + 0x10;
      uVar15 = uVar15 << 0x10 | (uint)uVar2;
    }

    iVar13 = iVar14 + -1;
    iVar6 = uVar15 << (0x1fU - iVar13 & 0x1f);

    if ( (iVar6 < 0) && (iVar7 < 2) ) break;

    puVar10 = &param_18 + iVar7;

    if ( iVar6 < 0 )
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;
      *unaff_s3 = (&param_16)[iVar7];
      iVar6 = iVar7 + -1;
      unaff_s3[1] = (&param_17)[iVar7];
      *(undefined4 **)(&param_16 + iVar7) = unaff_s3;
      unaff_s3 = unaff_s3 + 3;
    }
    else
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;

      if ( iVar13 < 8 )
      {
        if ( puVar9 < puVar16 )
        {
          uVar2 = *puVar9;
        }
        else
        {
          param_17 = iVar7;
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          iVar7 = param_17;
          puVar9 = unaff_s4;
        }

        puVar9 = puVar9 + 1;
        iVar13 = iVar14 + 0xf;
        uVar15 = uVar15 << 0x10 | (uint)uVar2;
      }

      iVar13 = iVar13 + -8;
      unaff_s3[2] = (uVar15 << (0x18U - iVar13 & 0x1f)) >> 0x18;
      *(undefined4 **)puVar10 = unaff_s3;
      iVar6 = iVar7 + 1;
      unaff_s3 = unaff_s3 + 3;
    }
  }

  iVar6 = 0;
  param_14 = (int **)0x0;
  param_22 = param_18;

  while ( true )
  {
    iVar7 = iVar6;
    iVar14 = iVar13;

    if ( iVar13 < 1 )
    {
      if ( puVar9 < puVar16 )
      {
        uVar2 = *puVar9;
      }
      else
      {
        param_13 = iVar6;
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        iVar7 = param_13;
        puVar9 = unaff_s4;
      }

      puVar9 = puVar9 + 1;
      iVar14 = iVar13 + 0x10;
      uVar15 = uVar15 << 0x10 | (uint)uVar2;
    }

    ppiVar3 = param_14;
    iVar13 = iVar14 + -1;
    iVar6 = uVar15 << (0x1fU - iVar13 & 0x1f);

    if ( (iVar6 < 0) && (iVar7 < 2) ) break;

    puVar10 = &param_14 + iVar7;

    if ( iVar6 < 0 )
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;
      *unaff_s3 = (&param_12)[iVar7];
      iVar6 = iVar7 + -1;
      unaff_s3[1] = (&param_13)[iVar7];
      *(undefined4 **)(&param_12 + iVar7) = unaff_s3;
      unaff_s3 = unaff_s3 + 3;
    }
    else
    {
      *unaff_s3 = 0;
      unaff_s3[1] = 0;
      unaff_s3[2] = 0;

      if ( iVar13 < 8 )
      {
        if ( puVar9 < puVar16 )
        {
          uVar2 = *puVar9;
        }
        else
        {
          param_13 = iVar7;
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          iVar7 = param_13;
          puVar9 = unaff_s4;
        }

        puVar9 = puVar9 + 1;
        iVar13 = iVar14 + 0xf;
        uVar15 = uVar15 << 0x10 | (uint)uVar2;
      }

      iVar13 = iVar13 + -8;
      unaff_s3[2] = (uVar15 << (0x18U - iVar13 & 0x1f)) >> 0x18;
      *(undefined4 **)puVar10 = unaff_s3;
      iVar6 = iVar7 + 1;
      unaff_s3 = unaff_s3 + 3;
    }
  }

  while ( param_23 < param_20 )
  {
    if ( iVar13 < 1 )
    {
      if ( puVar9 < puVar16 )
      {
        uVar2 = *puVar9;
      }
      else
      {
        (*unaff_s6)();
        uVar2 = *unaff_s4;
        puVar9 = unaff_s4;
      }

      puVar9 = puVar9 + 1;
      iVar13 = iVar13 + 0x10;
      uVar15 = uVar15 << 0x10 | (uint)uVar2;
    }

    iVar6 = iVar13 + -1;

    if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
    {
      piVar4 = *param_22;
      ppiVar11 = param_22;

      if ( param_19 == 0 )
      {
        while ( piVar4 != (int *)0x0 )
        {
          if ( iVar6 < 1 )
          {
            if ( puVar9 < puVar16 )
            {
              uVar2 = *puVar9;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              puVar9 = unaff_s4;
            }

            puVar9 = puVar9 + 1;
            iVar6 = iVar6 + 0x10;
            uVar15 = uVar15 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
          {
            ppiVar11 = (int **)ppiVar11[1];
          }
          else
          {
            ppiVar11 = (int **)*ppiVar11;
          }

          piVar4 = *ppiVar11;
        }

        piVar4 = ppiVar11[2];

        if ( iVar6 < (int)piVar4 )
        {
          if ( puVar9 < puVar16 )
          {
            uVar2 = *puVar9;
          }
          else
          {
            (*unaff_s6)();
            piVar4 = ppiVar11[2];
            uVar2 = *unaff_s4;
            puVar9 = unaff_s4;
          }

          puVar9 = puVar9 + 1;
          iVar6 = iVar6 + 0x10;
          uVar15 = uVar15 << 0x10 | (uint)uVar2;
        }

        iVar6 = iVar6 - (int)piVar4;
        iVar13 = -((uVar15 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU));
        piVar4 = *ppiVar3;
      }
      else
      {
        in_stack_00000064 = 0;

        while ( piVar4 != (int *)0x0 )
        {
          if ( iVar6 < 1 )
          {
            if ( puVar9 < puVar16 )
            {
              uVar2 = *puVar9;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              puVar9 = unaff_s4;
            }

            puVar9 = puVar9 + 1;
            iVar6 = iVar6 + 0x10;
            uVar15 = uVar15 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
          {
            ppiVar11 = (int **)ppiVar11[1];
          }
          else
          {
            ppiVar11 = (int **)*ppiVar11;
          }

          piVar4 = *ppiVar11;
        }

        piVar4 = ppiVar11[2];

        if ( iVar6 < (int)piVar4 )
        {
          if ( puVar9 < puVar16 )
          {
            uVar2 = *puVar9;
          }
          else
          {
            (*unaff_s6)();
            piVar4 = ppiVar11[2];
            uVar2 = *unaff_s4;
            puVar9 = unaff_s4;
          }

          puVar9 = puVar9 + 1;
          iVar6 = iVar6 + 0x10;
          uVar15 = uVar15 << 0x10 | (uint)uVar2;
        }

        iVar6 = iVar6 - (int)piVar4;
        uVar5 = (uVar15 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

        if ( (int)uVar5 < 3 )
        {
          in_stack_00000064 = uVar5 + 1;
          ppiVar11 = param_22;

          if ( *param_22 == (int *)0x0 )
          {
            piVar4 = param_22[2];
          }
          else
          {
            do
            {
              if ( iVar6 < 1 )
              {
                if ( puVar9 < puVar16 )
                {
                  uVar2 = *puVar9;
                }
                else
                {
                  (*unaff_s6)();
                  uVar2 = *unaff_s4;
                  puVar9 = unaff_s4;
                }

                puVar9 = puVar9 + 1;
                iVar6 = iVar6 + 0x10;
                uVar15 = uVar15 << 0x10 | (uint)uVar2;
              }

              iVar6 = iVar6 + -1;

              if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
              {
                ppiVar11 = (int **)ppiVar11[1];
              }
              else
              {
                ppiVar11 = (int **)*ppiVar11;
              }
            }
            while (*ppiVar11 != (int *)0x0);

            piVar4 = ppiVar11[2];
          }

          if ( iVar6 < (int)piVar4 )
          {
            if ( puVar9 < puVar16 )
            {
              uVar2 = *puVar9;
            }
            else
            {
              (*unaff_s6)();
              piVar4 = ppiVar11[2];
              uVar2 = *unaff_s4;
              puVar9 = unaff_s4;
            }

            puVar9 = puVar9 + 1;
            iVar6 = iVar6 + 0x10;
            uVar15 = uVar15 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 - (int)piVar4;
          uVar5 = (uVar15 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);
        }

        iVar13 = (uVar5 * -4 - in_stack_00000064) + 8;
        piVar4 = *ppiVar3;
      }

      puVar12 = puVar17 + iVar13;
      ppiVar11 = ppiVar3;

      if ( piVar4 == (int *)0x0 )
      {
        piVar4 = ppiVar3[2];
      }
      else
      {
        do
        {
          if ( iVar6 < 1 )
          {
            if ( puVar9 < puVar16 )
            {
              uVar2 = *puVar9;
            }
            else
            {
              (*unaff_s6)();
              uVar2 = *unaff_s4;
              puVar9 = unaff_s4;
            }

            puVar9 = puVar9 + 1;
            iVar6 = iVar6 + 0x10;
            uVar15 = uVar15 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 + -1;

          if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
          {
            ppiVar11 = (int **)ppiVar11[1];
          }
          else
          {
            ppiVar11 = (int **)*ppiVar11;
          }
        }
        while ( *ppiVar11 != (int *)0x0 );

        piVar4 = ppiVar11[2];
      }

      if ( iVar6 < (int)piVar4 )
      {
        if ( puVar9 < puVar16 )
        {
          uVar2 = *puVar9;
        }
        else
        {
          (*unaff_s6)();
          piVar4 = ppiVar11[2];
          uVar2 = *unaff_s4;
          puVar9 = unaff_s4;
        }

        puVar9 = puVar9 + 1;
        iVar6 = iVar6 + 0x10;
        uVar15 = uVar15 << 0x10 | (uint)uVar2;
      }

      iVar13 = iVar6 - (int)piVar4;
      uVar5 = (uVar15 << (-iVar13 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

      while ( param_23 = puVar17, 0 < (int)uVar5 )
      {
        uVar5 = uVar5 - 1;
        uVar1 = *puVar12;
        puVar12 = puVar12 + 1;
        *puVar17 = uVar1;
        puVar17 = puVar17 + 1;
      }
    }
    else
    {
      if ( iVar6 < 8 )
      {
        if ( puVar9 < puVar16 )
        {
          uVar2 = *puVar9;
        }
        else
        {
          (*unaff_s6)();
          uVar2 = *unaff_s4;
          puVar9 = unaff_s4;
        }

        puVar9 = puVar9 + 1;
        iVar6 = iVar13 + 0xf;
        uVar15 = uVar15 << 0x10 | (uint)uVar2;
      }

      iVar13 = iVar6 + -8;
      *puVar17 = (char)((uVar15 << (0x18U - iVar13 & 0x1f)) >> 0x18);
      puVar17 = puVar17 + 1;
      param_23 = puVar17;
    }
  }

  return;
}
