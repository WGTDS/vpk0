/*  vpk0 Decode Function Instance #6
 *  Decompiled from Kirby 64: The Crystal Shards [NK4E]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;
typedef uint undefined4;

void FUN_801039e8( ushort *param_1, undefined *param_2, undefined4 *param_3, int param_4 )
{
  undefined uVar1;
  ushort uVar2;
  int in_v0;
  int iVar3;
  uint in_v1;
  int **ppiVar4;
  undefined *in_t0;
  int **in_t1;
  int in_t2;
  int in_t3;
  int in_t4;
  undefined *in_t5;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  undefined *puVar9;
  int in_t9;
  int *param_11;
  int in_stack_0000010c;
  
  do
  {
    if ( in_t2 == 0 )
    {
      *param_3 = 0;
      param_3[1] = 0;
      param_3[2] = 0;

      if ( in_v0 < 8 )
      {
        uVar2 = *param_1;
        param_1 = param_1 + 1;
        in_v0 = in_v0 + 0x10;
        in_v1 = in_v1 << 0x10 | (uint)uVar2;
      }

      in_v0 = in_v0 + -8;
      param_3[2] = (in_v1 << (in_t3 - in_v0 & 0x1fU)) >> 0x18;
      *(undefined4 **)((int)&stack0x0000005c + in_t9) = param_3;
      in_t4 = in_t4 + 1;
    }
    else
    {
      *param_3 = 0;
      param_3[1] = 0;
      param_3[2] = 0;
      *param_3 = *(undefined4 *)(&stack0x00000054 + in_t9);
      in_t4 = in_t4 + -1;
      param_3[1] = *(undefined4 *)(&stack0x00000058 + in_t9);
      *(undefined4 **)(&stack0x00000054 + in_t9) = param_3;
    }

    param_3 = param_3 + 3;

    if ( in_v0 < 1 )
    {
      uVar2 = *param_1;
      param_1 = param_1 + 1;
      in_v0 = in_v0 + 0x10;
      in_v1 = in_v1 << 0x10 | (uint)uVar2;
    }

    in_v0 = in_v0 + -1;
    in_t2 = -((int)(in_v1 << (param_4 - in_v0 & 0x1fU)) >> 0x1f);
    in_t9 = in_t4 << 2;
  }
  while ( (in_t2 == 0) || (1 < in_t4) );

  if ( param_2 < in_t5 )
  {
    do
    {
      if ( in_v0 < 1 )
      {
        uVar2 = *param_1;
        param_1 = param_1 + 1;
        in_v1 = in_v1 << 0x10 | (uint)uVar2;
        iVar3 = in_v0 + 0xf;
      }
      else
      {
        iVar3 = in_v0 + -1;
      }

      if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
      {
        piVar8 = *in_t1;
        ppiVar4 = in_t1;

        if ( in_stack_0000010c == 0 )
        {
          while ( piVar8 != (int *)0x0 )
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar4 = (int **)ppiVar4[1];
            }
            else
            {
              ppiVar4 = (int **)*ppiVar4;
            }

            piVar8 = *ppiVar4;
          }

          piVar8 = ppiVar4[2];

          if ( iVar3 < (int)piVar8 )
          {
            uVar2 = *param_1;
            param_1 = param_1 + 1;
            iVar3 = iVar3 + 0x10;
            in_v1 = in_v1 << 0x10 | (uint)uVar2;
          }

          iVar3 = iVar3 - (int)piVar8;
          iVar6 = -((in_v1 << ((0x20 - (int)piVar8) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar8 & 0x1f));
        }
        else
        {
          iVar6 = 0;
          piVar5 = piVar8;

          while ( piVar5 != (int *)0x0 )
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar4 = (int **)ppiVar4[1];
            }
            else
            {
              ppiVar4 = (int **)*ppiVar4;
            }

            piVar5 = *ppiVar4;
          }

          piVar5 = ppiVar4[2];

          if ( iVar3 < (int)piVar5 )
          {
            uVar2 = *param_1;
            param_1 = param_1 + 1;
            iVar3 = iVar3 + 0x10;
            in_v1 = in_v1 << 0x10 | (uint)uVar2;
          }

          iVar3 = iVar3 - (int)piVar5;
          uVar7 = (in_v1 << ((0x20 - (int)piVar5) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar5 & 0x1f);

          if ( (int)uVar7 < 3 )
          {
            iVar6 = uVar7 + 1;
            ppiVar4 = in_t1;

            while ( piVar8 != (int *)0x0 )
            {
              if ( iVar3 < 1 )
              {
                uVar2 = *param_1;
                param_1 = param_1 + 1;
                in_v1 = in_v1 << 0x10 | (uint)uVar2;
                iVar3 = iVar3 + 0xf;
              }
              else
              {
                iVar3 = iVar3 + -1;
              }

              if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
              {
                ppiVar4 = (int **)ppiVar4[1];
              }
              else
              {
                ppiVar4 = (int **)*ppiVar4;
              }

              piVar8 = *ppiVar4;
            }

            piVar8 = ppiVar4[2];

            if ( iVar3 < (int)piVar8 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              iVar3 = iVar3 + 0x10;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
            }

            iVar3 = iVar3 - (int)piVar8;
            uVar7 = (in_v1 << ((0x20 - (int)piVar8) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar8 & 0x1f);
          }

          iVar6 = (uVar7 * -4 - iVar6) + 8;
        }

        puVar9 = in_t0 + iVar6;
        ppiVar4 = (int **)param_11;

        if ( *param_11 == 0 )
        {
          iVar6 = param_11[2];
        }
        else
        {
          do
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *param_1;
              param_1 = param_1 + 1;
              in_v1 = in_v1 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
            {
              ppiVar4 = (int **)ppiVar4[1];
            }
            else
            {
              ppiVar4 = (int **)*ppiVar4;
            }
          }
          while ( *ppiVar4 != (int *)0x0 );

          iVar6 = ((int *)ppiVar4)[2];
        }

        if ( iVar3 < iVar6 )
        {
          uVar2 = *param_1;
          param_1 = param_1 + 1;
          iVar3 = iVar3 + 0x10;
          in_v1 = in_v1 << 0x10 | (uint)uVar2;
        }

        in_v0 = iVar3 - iVar6;
        uVar7 = (in_v1 << ((0x20 - iVar6) - in_v0 & 0x1fU)) >> (0x20U - iVar6 & 0x1f);

        while ( 0 < (int)uVar7 )
        {
          uVar7 = uVar7 - 1;
          uVar1 = *puVar9;
          puVar9 = puVar9 + 1;
          *in_t0 = uVar1;
          in_t0 = in_t0 + 1;
        }
      }
      else
      {
        if ( iVar3 < 8 )
        {
          uVar2 = *param_1;
          param_1 = param_1 + 1;
          in_v1 = in_v1 << 0x10 | (uint)uVar2;
          in_v0 = iVar3 + 8;
        }
        else
        {
          in_v0 = iVar3 + -8;
        }

        *in_t0 = (char)((in_v1 << (in_t3 - in_v0 & 0x1fU)) >> 0x18);
        in_t0 = in_t0 + 1;
      }
    }
    while ( in_t0 < in_t5 );
  }

  return;
}
