/*  vpk0 Decode Function Instance #1
 *  Decompiled from Kirby 64: The Crystal Shards [NK4E]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;

void FUN_80102fc0( ushort *param_1, int param_2, undefined *param_3, undefined *param_4 )
{
  undefined uVar1;
  ushort uVar2;
  int **ppiVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  ushort *puVar8;
  ushort *puVar9;
  int ***pppiVar10;
  int **ppiVar11;
  undefined *puVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  ushort *puVar16;
  int iStack1012;
  int *piStack988;
  int iStack984;
  int **appiStack980 [20];
  int **ppiStack900;
  int *piStack892;
  int iStack888;
  int **appiStack884 [20];
  uint uStack804;
  undefined *puStack800;
  int **ppiStack792;
  int **ppiStack788;
  int *apiStack780 [195];
  
  (*(code *)param_3)();
  puVar16 = (ushort *)((int)param_1 + param_2);
  puVar9 = param_1 + 1;

  if ( puVar16 <= param_1 + 1 )
  {
    (*(code *)param_3)();
    puVar9 = param_1;
  }

  puVar8 = puVar9 + 1;

  if ( puVar16 <= puVar9 + 1 )
  {
    (*(code *)param_3)();
    puVar8 = param_1;
  }

  uVar2 = *puVar8;
  iVar13 = 0;
  puVar9 = puVar8 + 1;

  if ( puVar16 <= puVar8 + 1 )
  {
    (*(code *)param_3)();
    puVar9 = param_1;
  }

  uVar15 = CONCAT22( uVar2, *puVar9 );
  puStack800 = param_4 + uVar15;
  puVar9 = puVar9 + 1;

  if ( true )
  {
    if ( puVar9 < puVar16 )
    {
      uVar2 = *puVar9;
    }
    else
    {
      (*(code *)param_3)();
      uVar2 = *param_1;
      puVar9 = param_1;
    }

    puVar9 = puVar9 + 1;
    iVar13 = 0x10;
    uVar15 = uVar15 << 0x10 | (uint)uVar2;
  }

  iVar13 = iVar13 + -8;
  uStack804 = (uVar15 << (0x18U - iVar13 & 0x1f)) >> 0x18;
  iVar6 = 0;
  appiStack884[0] = (int **)0x0;
  ppiVar3 = apiStack780;

  while ( true )
  {
    iVar7 = iVar6;
    iVar14 = iVar13;

    if ( iVar13 < 1 )
    {
      if ( puVar9 < puVar16 )
      {
        uVar2 = *puVar9;
      }
      else
      {
        iStack888 = iVar6;
        (*(code *)param_3)();
        uVar2 = *param_1;
        iVar7 = iStack888;
        puVar9 = param_1;
      }

      puVar9 = puVar9 + 1;
      iVar14 = iVar13 + 0x10;
      uVar15 = uVar15 << 0x10 | (uint)uVar2;
    }

    iVar13 = iVar14 + -1;
    iVar6 = uVar15 << (0x1fU - iVar13 & 0x1f);

    if ( (iVar6 < 0) && (iVar7 < 2) ) break;

    pppiVar10 = appiStack884 + iVar7;

    if ( iVar6 < 0 )
    {
      *ppiVar3 = (int *)0x0;
      ppiVar3[1] = (int *)0x0;
      ppiVar3[2] = (int *)0x0;
      *ppiVar3 = (&piStack892)[iVar7];
      iVar6 = iVar7 + -1;
      ppiVar3[1] = (&piStack892)[iVar7 + 1];
      *(int ***)(&piStack892 + iVar7) = ppiVar3;
      ppiVar3 = ppiVar3 + 3;
    }
    else
    {
      ppiVar11 = ppiVar3 + 3;
      *ppiVar3 = (int *)0x0;
      ppiVar3[1] = (int *)0x0;
      ppiVar3[2] = (int *)0x0;

      if ( iVar13 < 8 )
      {
        if ( puVar9 < puVar16 )
        {
          uVar2 = *puVar9;
        }
        else
        {
          ppiStack900 = ppiVar3;
          iStack888 = iVar7;
          (*(code *)param_3)();
          uVar2 = *param_1;
          ppiVar3 = ppiStack900;
          iVar7 = iStack888;
          puVar9 = param_1;
        }

        puVar9 = puVar9 + 1;
        iVar13 = iVar14 + 0xf;
        uVar15 = uVar15 << 0x10 | (uint)uVar2;
      }

      iVar13 = iVar13 + -8;
      ppiVar3[2] = (int *)((uVar15 << (0x18U - iVar13 & 0x1f)) >> 0x18);
      *pppiVar10 = ppiVar3;
      iVar6 = iVar7 + 1;
      ppiVar3 = ppiVar11;
    }
  }

  iVar6 = 0;
  appiStack980[0] = (int **)0x0;
  ppiStack788 = appiStack884[0];

  while ( true )
  {
    iVar7 = iVar6;
    iVar14 = iVar13;

    if ( iVar13 < 1 )
    {
      if ( puVar9 < puVar16 )
      {
        uVar2 = *puVar9;
      }
      else
      {
        iStack984 = iVar6;
        (*(code *)param_3)();
        uVar2 = *param_1;
        iVar7 = iStack984;
        puVar9 = param_1;
      }

      puVar9 = puVar9 + 1;
      iVar14 = iVar13 + 0x10;
      uVar15 = uVar15 << 0x10 | (uint)uVar2;
    }

    iVar13 = iVar14 + -1;
    iVar6 = uVar15 << (0x1fU - iVar13 & 0x1f);

    if ( (iVar6 < 0) && (iVar7 < 2) ) break;

    pppiVar10 = appiStack980 + iVar7;

    if ( iVar6 < 0 )
    {
      *ppiVar3 = (int *)0x0;
      ppiVar3[1] = (int *)0x0;
      ppiVar3[2] = (int *)0x0;
      *ppiVar3 = (&piStack988)[iVar7];
      iVar6 = iVar7 + -1;
      ppiVar3[1] = (&piStack988)[iVar7 + 1];
      *(int ***)(&piStack988 + iVar7) = ppiVar3;
      ppiVar3 = ppiVar3 + 3;
    }
    else
    {
      *ppiVar3 = (int *)0x0;
      ppiVar3[1] = (int *)0x0;
      ppiVar3[2] = (int *)0x0;

      if ( iVar13 < 8 )
      {
        if ( puVar9 < puVar16 )
        {
          uVar2 = *puVar9;
        }
        else
        {
          iStack984 = iVar7;
          (*(code *)param_3)();
          uVar2 = *param_1;
          iVar7 = iStack984;
          puVar9 = param_1;
        }

        puVar9 = puVar9 + 1;
        iVar13 = iVar14 + 0xf;
        uVar15 = uVar15 << 0x10 | (uint)uVar2;
      }

      iVar13 = iVar13 + -8;
      ppiVar3[2] = (int *)((uVar15 << (0x18U - iVar13 & 0x1f)) >> 0x18);
      *pppiVar10 = ppiVar3;
      iVar6 = iVar7 + 1;
      ppiVar3 = ppiVar3 + 3;
    }
  }

  ppiStack792 = appiStack980[0];

  if ( param_4 < puStack800 )
  {
    do
    {
      if ( iVar13 < 1 )
      {
        if ( puVar9 < puVar16 )
        {
          uVar2 = *puVar9;
        }
        else
        {
          (*(code *)param_3)();
          uVar2 = *param_1;
          puVar9 = param_1;
        }

        puVar9 = puVar9 + 1;
        iVar13 = iVar13 + 0x10;
        uVar15 = uVar15 << 0x10 | (uint)uVar2;
      }

      ppiVar3 = ppiStack792;
      iVar6 = iVar13 + -1;

      if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
      {
        piVar4 = *ppiStack788;
        ppiVar11 = ppiStack788;

        if ( uStack804 == 0 )
        {
          while ( piVar4 != (int *)0x0 )
          {
            if ( iVar6 < 1 )
            {
              if ( puVar9 < puVar16 )
              {
                uVar2 = *puVar9;
              }
              else
              {
                (*(code *)param_3)();
                uVar2 = *param_1;
                puVar9 = param_1;
              }

              puVar9 = puVar9 + 1;
              iVar6 = iVar6 + 0x10;
              uVar15 = uVar15 << 0x10 | (uint)uVar2;
            }

            iVar6 = iVar6 + -1;

            if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
            {
              ppiVar11 = (int **)ppiVar11[1];
            }
            else
            {
              ppiVar11 = (int **)*ppiVar11;
            }

            piVar4 = *ppiVar11;
          }

          piVar4 = ppiVar11[2];

          if ( iVar6 < (int)piVar4 )
          {
            if ( puVar9 < puVar16 )
            {
              uVar2 = *puVar9;
            }
            else
            {
              (*(code *)param_3)();
              piVar4 = ppiVar11[2];
              uVar2 = *param_1;
              puVar9 = param_1;
            }

            puVar9 = puVar9 + 1;
            iVar6 = iVar6 + 0x10;
            uVar15 = uVar15 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 - (int)piVar4;
          iVar13 = -((uVar15 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU));
          piVar4 = *ppiStack792;
        }
        else
        {
          iStack1012 = 0;

          while ( piVar4 != (int *)0x0 )
          {
            if ( iVar6 < 1 )
            {
              if ( puVar9 < puVar16 )
              {
                uVar2 = *puVar9;
              }
              else
              {
                (*(code *)param_3)();
                uVar2 = *param_1;
                puVar9 = param_1;
              }

              puVar9 = puVar9 + 1;
              iVar6 = iVar6 + 0x10;
              uVar15 = uVar15 << 0x10 | (uint)uVar2;
            }

            iVar6 = iVar6 + -1;

            if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
            {
              ppiVar11 = (int **)ppiVar11[1];
            }
            else
            {
              ppiVar11 = (int **)*ppiVar11;
            }

            piVar4 = *ppiVar11;
          }

          piVar4 = ppiVar11[2];

          if ( iVar6 < (int)piVar4 )
          {
            if ( puVar9 < puVar16 )
            {
              uVar2 = *puVar9;
            }
            else
            {
              (*(code *)param_3)();
              piVar4 = ppiVar11[2];
              uVar2 = *param_1;
              puVar9 = param_1;
            }

            puVar9 = puVar9 + 1;
            iVar6 = iVar6 + 0x10;
            uVar15 = uVar15 << 0x10 | (uint)uVar2;
          }

          iVar6 = iVar6 - (int)piVar4;
          uVar5 = (uVar15 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

          if ( (int)uVar5 < 3 )
          {
            iStack1012 = uVar5 + 1;
            ppiVar11 = ppiStack788;

            if ( *ppiStack788 == (int *)0x0 )
            {
              piVar4 = ppiStack788[2];
            }
            else
            {
              do
              {
                if ( iVar6 < 1 )
                {
                  if ( puVar9 < puVar16 )
                  {
                    uVar2 = *puVar9;
                  }
                  else
                  {
                    (*(code *)param_3)();
                    uVar2 = *param_1;
                    puVar9 = param_1;
                  }

                  puVar9 = puVar9 + 1;
                  iVar6 = iVar6 + 0x10;
                  uVar15 = uVar15 << 0x10 | (uint)uVar2;
                }

                iVar6 = iVar6 + -1;

                if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
                {
                  ppiVar11 = (int **)ppiVar11[1];
                }
                else
                {
                  ppiVar11 = (int **)*ppiVar11;
                }
              }
              while ( *ppiVar11 != (int *)0x0 );

              piVar4 = ppiVar11[2];
            }

            if ( iVar6 < (int)piVar4 )
            {
              if ( puVar9 < puVar16 )
              {
                uVar2 = *puVar9;
              }
              else
              {
                (*(code *)param_3)();
                piVar4 = ppiVar11[2];
                uVar2 = *param_1;
                puVar9 = param_1;
              }

              puVar9 = puVar9 + 1;
              iVar6 = iVar6 + 0x10;
              uVar15 = uVar15 << 0x10 | (uint)uVar2;
            }

            iVar6 = iVar6 - (int)piVar4;
            uVar5 = (uVar15 << (-iVar6 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);
          }

          iVar13 = (uVar5 * -4 - iStack1012) + 8;
          piVar4 = *ppiStack792;
        }

        puVar12 = param_4 + iVar13;

        if ( piVar4 == (int *)0x0 )
        {
          piVar4 = ppiVar3[2];
        }
        else
        {
          do
          {
            if ( iVar6 < 1 )
            {
              if ( puVar9 < puVar16 )
              {
                uVar2 = *puVar9;
              }
              else
              {
                (*(code *)param_3)();
                uVar2 = *param_1;
                puVar9 = param_1;
              }

              puVar9 = puVar9 + 1;
              iVar6 = iVar6 + 0x10;
              uVar15 = uVar15 << 0x10 | (uint)uVar2;
            }

            iVar6 = iVar6 + -1;

            if ( (int)(uVar15 << (0x1fU - iVar6 & 0x1f)) < 0 )
            {
              ppiVar3 = (int **)ppiVar3[1];
            }
            else
            {
              ppiVar3 = (int **)*ppiVar3;
            }
          }
          while ( *ppiVar3 != (int *)0x0 );

          piVar4 = ppiVar3[2];
        }

        if ( iVar6 < (int)piVar4 )
        {
          if ( puVar9 < puVar16 )
          {
            uVar2 = *puVar9;
          }
          else
          {
            (*(code *)param_3)();
            piVar4 = ppiVar3[2];
            uVar2 = *param_1;
            puVar9 = param_1;
          }

          puVar9 = puVar9 + 1;
          iVar6 = iVar6 + 0x10;
          uVar15 = uVar15 << 0x10 | (uint)uVar2;
        }

        iVar13 = iVar6 - (int)piVar4;
        uVar5 = (uVar15 << (-iVar13 - (int)piVar4 & 0x1fU)) >> (-(int)piVar4 & 0x1fU);

        while ( 0 < (int)uVar5 )
        {
          uVar5 = uVar5 - 1;
          uVar1 = *puVar12;
          puVar12 = puVar12 + 1;
          *param_4 = uVar1;
          param_4 = param_4 + 1;
        }
      }
      else
      {
        if ( iVar6 < 8 )
        {
          if ( puVar9 < puVar16 )
          {
            uVar2 = *puVar9;
          }
          else
          {
            (*(code *)param_3)();
            uVar2 = *param_1;
            puVar9 = param_1;
          }

          puVar9 = puVar9 + 1;
          iVar6 = iVar13 + 0xf;
          uVar15 = uVar15 << 0x10 | (uint)uVar2;
        }

        iVar13 = iVar6 + -8;
        *param_4 = (char)((uVar15 << (0x18U - iVar13 & 0x1f)) >> 0x18);
        param_4 = param_4 + 1;
      }
    }
    while ( param_4 < puStack800 );
  }

  return;
}
