/*  vpk0 Decode Function Instance #5
 *  Decompiled from Kirby 64: The Crystal Shards [NK4E]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;

void FUN_8010385c( int param_1, undefined *param_2 )
{
  undefined uVar1;
  ushort uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  ushort *puVar6;
  int **ppiVar7;
  int iVar8;
  int iVar9;
  undefined *puVar10;
  int *piVar11;
  uint uVar12;
  undefined *puVar13;
  int **appiStack988 [24];
  int **appiStack892 [22];
  uint local_324;
  int *apiStack780 [195];
  
  puVar10 = param_2 + *(int *)(param_1 + 4);
  iVar3 = 8;
  uVar5 = *(int *)(param_1 + 4) << 0x10 | (uint)*(ushort *)(param_1 + 8);
  local_324 = ((uint)*(ushort *)(param_1 + 8) << 0x10) >> 0x18;
  puVar6 = (ushort *)(param_1 + 10);
  appiStack892[2] = (int **)0x0;
  ppiVar7 = apiStack780;
  iVar8 = 0;

  while ( true )
  {
    iVar4 = iVar3;

    if ( iVar3 < 1 )
    {
      uVar2 = *puVar6;
      puVar6 = puVar6 + 1;
      iVar4 = iVar3 + 0x10;
      uVar5 = uVar5 << 0x10 | (uint)uVar2;
    }

    iVar3 = iVar4 + -1;
    iVar9 = uVar5 << (0x1fU - iVar3 & 0x1f);

    if ( (iVar9 < 0) && (iVar8 < 2) ) break;

    if ( iVar9 < 0 )
    {
      *ppiVar7 = (int *)0x0;
      ppiVar7[1] = (int *)0x0;
      ppiVar7[2] = (int *)0x0;
      *(int ***)ppiVar7 = appiStack892[iVar8];
      *(int ***)(ppiVar7 + 1) = appiStack892[iVar8 + 1];
      appiStack892[iVar8] = ppiVar7;
      ppiVar7 = ppiVar7 + 3;
      iVar8 = iVar8 + -1;
    }
    else
    {
      *ppiVar7 = (int *)0x0;
      ppiVar7[1] = (int *)0x0;
      ppiVar7[2] = (int *)0x0;

      if ( iVar3 < 8 )
      {
        uVar2 = *puVar6;
        puVar6 = puVar6 + 1;
        iVar3 = iVar4 + 0xf;
        uVar5 = uVar5 << 0x10 | (uint)uVar2;
      }

      iVar3 = iVar3 + -8;
      ppiVar7[2] = (int *)((uVar5 << (0x18U - iVar3 & 0x1f)) >> 0x18);
      appiStack892[iVar8 + 2] = ppiVar7;
      iVar8 = iVar8 + 1;
      ppiVar7 = ppiVar7 + 3;
    }
  }

  appiStack988[2] = (int **)0x0;
  iVar8 = 0;

  while ( true )
  {
    iVar4 = iVar3;

    if ( iVar3 < 1 )
    {
      uVar2 = *puVar6;
      puVar6 = puVar6 + 1;
      iVar4 = iVar3 + 0x10;
      uVar5 = uVar5 << 0x10 | (uint)uVar2;
    }

    iVar3 = iVar4 + -1;
    iVar9 = uVar5 << (0x1fU - iVar3 & 0x1f);

    if ( (iVar9 < 0) && (iVar8 < 2) ) break;

    if ( iVar9 < 0 )
    {
      *ppiVar7 = (int *)0x0;
      ppiVar7[1] = (int *)0x0;
      ppiVar7[2] = (int *)0x0;
      *(int ***)ppiVar7 = appiStack988[iVar8];
      *(int ***)(ppiVar7 + 1) = appiStack988[iVar8 + 1];
      appiStack988[iVar8] = ppiVar7;
      ppiVar7 = ppiVar7 + 3;
      iVar8 = iVar8 + -1;
    }
    else
    {
      *ppiVar7 = (int *)0x0;
      ppiVar7[1] = (int *)0x0;
      ppiVar7[2] = (int *)0x0;

      if ( iVar3 < 8 )
      {
        uVar2 = *puVar6;
        puVar6 = puVar6 + 1;
        iVar3 = iVar4 + 0xf;
        uVar5 = uVar5 << 0x10 | (uint)uVar2;
      }

      iVar3 = iVar3 + -8;
      ppiVar7[2] = (int *)((uVar5 << (0x18U - iVar3 & 0x1f)) >> 0x18);
      appiStack988[iVar8 + 2] = ppiVar7;
      iVar8 = iVar8 + 1;
      ppiVar7 = ppiVar7 + 3;
    }
  }

  if ( param_2 < puVar10 )
  {
    do
    {
      if ( iVar3 < 1 )
      {
        uVar2 = *puVar6;
        puVar6 = puVar6 + 1;
        uVar5 = uVar5 << 0x10 | (uint)uVar2;
        iVar3 = iVar3 + 0xf;
      }
      else
      {
        iVar3 = iVar3 + -1;
      }

      if ( (int)(uVar5 << (0x1fU - iVar3 & 0x1f)) < 0 )
      {
        ppiVar7 = appiStack892[2];
        piVar11 = piRam00000000; /* = *ppiVar7 */

        if ( local_324 == 0 )
        {
          while ( piVar11 != (int *)0x0 )
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *puVar6;
              puVar6 = puVar6 + 1;
              uVar5 = uVar5 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(uVar5 << (0x1fU - iVar3 & 0x1f)) < 0 )
            {
              ppiVar7 = (int **)ppiVar7[1];
            }
            else
            {
              ppiVar7 = (int **)*ppiVar7;
            }

            piVar11 = *ppiVar7;
          }

          piVar11 = ppiVar7[2];

          if ( iVar3 < (int)piVar11 )
          {
            uVar2 = *puVar6;
            puVar6 = puVar6 + 1;
            iVar3 = iVar3 + 0x10;
            uVar5 = uVar5 << 0x10 | (uint)uVar2;
          }

          iVar3 = iVar3 - (int)piVar11;
          iVar8 = -((uVar5 << ((0x20 - (int)piVar11) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar11 & 0x1f));
        }
        else
        {
          iVar8 = 0;

          while ( piVar11 != (int *)0x0 )
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *puVar6;
              puVar6 = puVar6 + 1;
              uVar5 = uVar5 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(uVar5 << (0x1fU - iVar3 & 0x1f)) < 0 )
            {
              ppiVar7 = (int **)ppiVar7[1];
            }
            else
            {
              ppiVar7 = (int **)*ppiVar7;
            }

            piVar11 = *ppiVar7;
          }

          piVar11 = ppiVar7[2];

          if ( iVar3 < (int)piVar11 )
          {
            uVar2 = *puVar6;
            puVar6 = puVar6 + 1;
            iVar3 = iVar3 + 0x10;
            uVar5 = uVar5 << 0x10 | (uint)uVar2;
          }

          iVar3 = iVar3 - (int)piVar11;
          uVar12 = (uVar5 << ((0x20 - (int)piVar11) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar11 & 0x1f);

          if ( (int)uVar12 < 3 )
          {
            iVar8 = uVar12 + 1;
            ppiVar7 = appiStack892[2];
            piVar11 = piRam00000000; /* = *ppiVar7 */

            while ( piVar11 != (int *)0x0 )
            {
              if ( iVar3 < 1 )
              {
                uVar2 = *puVar6;
                puVar6 = puVar6 + 1;
                uVar5 = uVar5 << 0x10 | (uint)uVar2;
                iVar3 = iVar3 + 0xf;
              }
              else
              {
                iVar3 = iVar3 + -1;
              }

              if ( (int)(uVar5 << (0x1fU - iVar3 & 0x1f)) < 0 )
              {
                ppiVar7 = (int **)ppiVar7[1];
              }
              else
              {
                ppiVar7 = (int **)*ppiVar7;
              }

              piVar11 = *ppiVar7;
            }

            piVar11 = ppiVar7[2];

            if ( iVar3 < (int)piVar11 )
            {
              uVar2 = *puVar6;
              puVar6 = puVar6 + 1;
              iVar3 = iVar3 + 0x10;
              uVar5 = uVar5 << 0x10 | (uint)uVar2;
            }

            iVar3 = iVar3 - (int)piVar11;
            uVar12 = (uVar5 << ((0x20 - (int)piVar11) - iVar3 & 0x1fU)) >> (0x20U - (int)piVar11 & 0x1f);
          }

          iVar8 = (uVar12 * -4 - iVar8) + 8;
        }

        puVar13 = param_2 + iVar8;
        ppiVar7 = appiStack988[2];
        iVar8 = DAT_00000008; /* = (int)ppiVar7[2] */

        if ( /* *ppiVar7 != */ piRam00000000 != (int *)0x0 )
        {
          do
          {
            if ( iVar3 < 1 )
            {
              uVar2 = *puVar6;
              puVar6 = puVar6 + 1;
              uVar5 = uVar5 << 0x10 | (uint)uVar2;
              iVar3 = iVar3 + 0xf;
            }
            else
            {
              iVar3 = iVar3 + -1;
            }

            if ( (int)(uVar5 << (0x1fU - iVar3 & 0x1f)) < 0 )
            {
              ppiVar7 = (int **)ppiVar7[1];
            }
            else
            {
              ppiVar7 = (int **)*ppiVar7;
            }
          }
          while ( *ppiVar7 != (int *)0x0 );

          iVar8 = (int)ppiVar7[2];
        }

        if ( iVar3 < iVar8 )
        {
          uVar2 = *puVar6;
          puVar6 = puVar6 + 1;
          iVar3 = iVar3 + 0x10;
          uVar5 = uVar5 << 0x10 | (uint)uVar2;
        }

        iVar3 = iVar3 - iVar8;
        uVar12 = (uVar5 << ((0x20 - iVar8) - iVar3 & 0x1fU)) >> (0x20U - iVar8 & 0x1f);

        while ( 0 < (int)uVar12 )
        {
          uVar12 = uVar12 - 1;
          uVar1 = *puVar13;
          puVar13 = puVar13 + 1;
          *param_2 = uVar1;
          param_2 = param_2 + 1;
        }
      }
      else
      {
        if ( iVar3 < 8 )
        {
          uVar2 = *puVar6;
          puVar6 = puVar6 + 1;
          uVar5 = uVar5 << 0x10 | (uint)uVar2;
          iVar3 = iVar3 + 8;
        }
        else
        {
          iVar3 = iVar3 + -8;
        }

        *param_2 = (char)((uVar5 << (0x18U - iVar3 & 0x1f)) >> 0x18);
        param_2 = param_2 + 1;
      }
    }
    while ( param_2 < puVar10 );
  }

  return;
}
