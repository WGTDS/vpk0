/*  vpk0 Decode Function Instance #9
 *  Decompiled from Kirby 64: The Crystal Shards [NK4E]
 *  using
 *  Ghidra 9.1.2
 *  and
 *  N64 Loader by Warranty Voider
 */
#include <stdint.h>
#include <stdbool.h>

typedef uint8_t undefined;
typedef uint16_t ushort;
typedef uint32_t uint;

void FUN_80103b58( ushort *param_1, int **param_2, int param_3, int param_4 )
{
  undefined uVar1;
  ushort uVar2;
  int in_v0;
  int iVar3;
  uint in_v1;
  undefined *in_t0;
  int **in_t1;
  int in_t2;
  int iVar4;
  int in_t3;
  int *in_t4;
  undefined *in_t5;
  int unaff_s0;
  int **ppiVar5;
  int **unaff_s1;
  uint uVar6;
  int *unaff_s2;
  undefined *puVar7;
  int *piVar8;
  int param_11;
  
  do
  {
    piVar8 = unaff_s1[2];

    if ( in_v0 < (int)piVar8 )
    {
      uVar2 = *param_1;
      param_1 = param_1 + 1;
      in_v0 = in_v0 + 0x10;
      in_v1 = in_v1 << 0x10 | (uint)uVar2;
    }

    iVar3 = in_v0 - (int)piVar8;
    uVar6 = (in_v1 << ((param_3 - (int)piVar8) - iVar3 & 0x1fU)) >> (param_3 - (int)piVar8 & 0x1fU);

    if ( (int)uVar6 < 3 )
    {
      unaff_s0 = uVar6 + 1;
      ppiVar5 = in_t1;

      while ( unaff_s2 != (int *)0x0 )
      {
        if ( iVar3 < 1 )
        {
          uVar2 = *param_1;
          param_1 = param_1 + 1;
          in_v1 = in_v1 << 0x10 | (uint)uVar2;
          iVar3 = iVar3 + 0xf;
        }
        else
        {
          iVar3 = iVar3 + -1;
        }

        if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
        {
          ppiVar5 = (int **)ppiVar5[1];
        }
        else
        {
          ppiVar5 = (int **)*ppiVar5;
        }

        unaff_s2 = *ppiVar5;
      }

      piVar8 = ppiVar5[2];

      if ( iVar3 < (int)piVar8 )
      {
        uVar2 = *param_1;
        param_1 = param_1 + 1;
        iVar3 = iVar3 + 0x10;
        in_v1 = in_v1 << 0x10 | (uint)uVar2;
      }

      iVar3 = iVar3 - (int)piVar8;
      uVar6 = (in_v1 << ((param_3 - (int)piVar8) - iVar3 & 0x1fU)) >> (param_3 - (int)piVar8 & 0x1fU);
    }

    puVar7 = in_t0 + (uVar6 * -4 - unaff_s0) + 8;

    while ( true )
    {
      if ( in_t2 == 0 )
      {
        iVar4 = ((int *)param_2)[2];
      }
      else
      {
        do
        {
          if ( iVar3 < 1 )
          {
            uVar2 = *param_1;
            param_1 = param_1 + 1;
            in_v1 = in_v1 << 0x10 | (uint)uVar2;
            iVar3 = iVar3 + 0xf;
          }
          else
          {
            iVar3 = iVar3 + -1;
          }

          if ( (int)(in_v1 << (param_4 - iVar3 & 0x1fU)) < 0 )
          {
            param_2 = (int **)param_2[1];
          }
          else
          {
            param_2 = (int **)*param_2;
          }
        }
        while ( *param_2 != (int *)0x0 );

        iVar4 = ((int *)param_2)[2];
      }

      if ( iVar3 < iVar4 )
      {
        uVar2 = *param_1;
        param_1 = param_1 + 1;
        iVar3 = iVar3 + 0x10;
        in_v1 = in_v1 << 0x10 | (uint)uVar2;
      }

      iVar3 = iVar3 - iVar4;
      uVar6 = (in_v1 << ((param_3 - iVar4) - iVar3 & 0x1fU)) >> (param_3 - iVar4 & 0x1fU);

      while ( 0 < (int)uVar6 )
      {
        uVar6 = uVar6 - 1;
        uVar1 = *puVar7;
        puVar7 = puVar7 + 1;
        *in_t0 = uVar1;
        in_t0 = in_t0 + 1;
      }

      while ( true )
      {
        if ( in_t5 <= in_t0 )
        {
          return;
        }

        if ( iVar3 < 1 )
        {
          uVar2 = *param_1;
          param_1 = param_1 + 1;
          in_v1 = in_v1 << 0x10 | (uint)uVar2;
          in_v0 = iVar3 + 0xf;
        }
        else
        {
          in_v0 = iVar3 + -1;
        }

        if ( (int)(in_v1 << (param_4 - in_v0 & 0x1fU)) < 0 ) break;

        if ( in_v0 < 8 )
        {
          uVar2 = *param_1;
          param_1 = param_1 + 1;
          in_v1 = in_v1 << 0x10 | (uint)uVar2;
          iVar3 = in_v0 + 8;
        }
        else
        {
          iVar3 = in_v0 + -8;
        }

        *in_t0 = (char)((in_v1 << (in_t3 - iVar3 & 0x1fU)) >> 0x18);
        in_t0 = in_t0 + 1;
      }

      unaff_s2 = *in_t1;
      in_t2 = *in_t4;
      ppiVar5 = in_t1;
      param_2 = (int **)in_t4;

      if ( param_11 != 0 ) break;

      while ( unaff_s2 != (int *)0x0 )
      {
        if ( in_v0 < 1 )
        {
          uVar2 = *param_1;
          param_1 = param_1 + 1;
          in_v1 = in_v1 << 0x10 | (uint)uVar2;
          in_v0 = in_v0 + 0xf;
        }
        else
        {
          in_v0 = in_v0 + -1;
        }

        if ( (int)(in_v1 << (param_4 - in_v0 & 0x1fU)) < 0 )
        {
          ppiVar5 = (int **)ppiVar5[1];
        }
        else
        {
          ppiVar5 = (int **)*ppiVar5;
        }

        unaff_s2 = *ppiVar5;
      }

      piVar8 = ppiVar5[2];

      if ( in_v0 < (int)piVar8 )
      {
        uVar2 = *param_1;
        param_1 = param_1 + 1;
        in_v0 = in_v0 + 0x10;
        in_v1 = in_v1 << 0x10 | (uint)uVar2;
      }

      iVar3 = in_v0 - (int)piVar8;
      puVar7 = in_t0 + -((in_v1 << ((param_3 - (int)piVar8) - iVar3 & 0x1fU)) >> (param_3 - (int)piVar8 & 0x1fU));
    }

    unaff_s0 = 0;
    unaff_s1 = in_t1;
    piVar8 = unaff_s2;

    while ( piVar8 != (int *)0x0 )
    {
      if ( in_v0 < 1 )
      {
        uVar2 = *param_1;
        param_1 = param_1 + 1;
        in_v1 = in_v1 << 0x10 | (uint)uVar2;
        in_v0 = in_v0 + 0xf;
      }
      else
      {
        in_v0 = in_v0 + -1;
      }

      if ( (int)(in_v1 << (param_4 - in_v0 & 0x1fU)) < 0 )
      {
        unaff_s1 = (int **)unaff_s1[1];
      }
      else
      {
        unaff_s1 = (int **)*unaff_s1;
      }

      piVar8 = *unaff_s1;
    }
  }
  while ( true );
}
